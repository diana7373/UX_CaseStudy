
  # Convert design to React

  This is a code bundle for Convert design to React. The original project is available at https://www.figma.com/design/Gx6M0btvcAQ9h8TtPDkk76/Convert-design-to-React.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  