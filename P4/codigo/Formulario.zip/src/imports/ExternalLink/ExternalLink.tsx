export default function ExternalLink() {
  return (
    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 38 38">
      <path
        d="M14.5 5.5H5.5C4.30653 5.5 3.16193 5.97411 2.31802 6.81802C1.47411 7.66193 1 8.80653 1 10V32.5C1 33.6935 1.47411 34.8381 2.31802 35.682C3.16193 36.5259 4.30653 37 5.5 37H28C29.1935 37 30.3381 36.5259 31.182 35.682C32.0259 34.8381 32.5 33.6935 32.5 32.5V23.5M37 14.5V1H23.5M37 1L14.5 23.5"
        stroke="white"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="2"
      />
    </svg>
  );
}
