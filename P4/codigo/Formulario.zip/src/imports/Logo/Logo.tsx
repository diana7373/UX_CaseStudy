import imgLogo from "./a989c9088a9b92c5e224205202d8c79f33d34c47.png";

interface LogoProps {
  className?: string;
}

export default function Logo({ className }: LogoProps) {
  return (
    <div className={className || "h-[80px] relative rounded-[4px] shrink-0 w-[82px]"} data-name="Logo">
      <img
        alt="Cyber-Gourmet Logo"
        className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none rounded-[4px] size-full"
        src={imgLogo}
      />
    </div>
  );
}
