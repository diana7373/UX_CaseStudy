import imgPersonalizacion from "./e1f2b024065461d3b9556f2184da512a79c1b0d8.png";

export default function Frame() {
  return (
    <div className="content-stretch flex items-center relative size-full">
      <div className="h-[1888px] relative shrink-0 w-[1834px]" data-name="Personalizacion">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgPersonalizacion} />
      </div>
    </div>
  );
}