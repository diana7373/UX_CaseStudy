import { Menu, Search, UserRound } from 'lucide-react';
import imgLogo from '../imports/Landing/a989c9088a9b92c5e224205202d8c79f33d34c47.png';
import imgHero from '../imports/Landing/1620db19378180dd57c01750022c56887dd6cd3d.png';
import imgFood1 from '../imports/Landing/caea84ae638c0685467a255ed8817c7bd4f7fb50.png';
import imgFood2 from '../imports/Landing/511e6668ef00f09bf40760217c05ed03bc88ae2f.png';
import imgFood3 from '../imports/Landing/d18c2ab4d37bfa9500f3a2210520c0567e470f9e.png';
import LogoFooter from '../imports/LogoFooter/LogoFooter';
import ExternalLink from '../imports/ExternalLink/ExternalLink';
import Link from '../imports/Link/Link';
import LocationMarker from '../imports/LocationMarker/LocationMarker';
import Phone from '../imports/Phone/Phone';
import Mail from '../imports/Mail/Mail';
import Annotation from '../imports/Annotation/Annotation';

export default function App() {
  return (
    <div className="bg-black min-h-screen text-white">
      {/* Header */}
      <header className="border-b border-black bg-[#572364] text-white">
        <div className="mx-auto grid max-w-[1947px] grid-cols-[1fr_auto_1fr] items-center gap-4 px-6 py-3 md:px-10 md:py-5">
          <button className="justify-self-start p-2 text-white transition hover:text-[#d94cff]" aria-label="Abrir menú">
            <Menu className="h-8 w-8" strokeWidth={2.4} />
          </button>
          <div className="relative h-[74px] w-[74px] overflow-hidden rounded border-4 border-black bg-black shadow-[0_0_0_1px_rgba(255,255,255,.25)] md:h-[92px] md:w-[92px]">
            <img src={imgLogo} alt="Logo Cyber-Gourmet" className="h-full w-full object-cover scale-[1.55]" />
          </div>
          <div className="flex items-center justify-end gap-4">
            <div className="hidden h-7 w-[32vw] max-w-[300px] border border-black bg-black md:block" />
            <button className="grid h-8 w-8 place-items-center bg-[#d1a0de] text-black transition hover:bg-[#c48ed1]">
              <Search className="h-5 w-5" />
            </button>
            <button className="grid h-8 w-8 place-items-center bg-white text-black transition hover:bg-gray-200">
              <UserRound className="h-5 w-5" />
            </button>
          </div>
        </div>
        <nav className="grid grid-cols-2 border-t border-black md:grid-cols-6">
          {['CARTA', 'PEDIDO', 'PERSONALIZACION', 'CONTACTO', 'SOBRE NOSOTROS', 'RESERVAR'].map((item) => (
            <button
              key={item}
              className={`flex min-h-[46px] items-center justify-center border-b border-r border-black px-1.5 text-center font-['Press_Start_2P'] text-[9px] leading-none transition hover:bg-[#6f2b80] hover:text-[#16c59a] sm:text-[10px] lg:text-[11px] xl:text-xs ${item === 'PERSONALIZACION' ? 'tracking-[-0.08em]' : 'tracking-[-0.03em]'}`}
            >
              <span className="whitespace-nowrap">{item}</span>
            </button>
          ))}
        </nav>
      </header>

      {/* Hero Section */}
      <section className="relative py-20">
        <div className="container mx-auto px-4 text-center">
          <div className="relative mx-auto max-w-[900px]">
            <img
              src={imgHero}
              alt="Cyber Gourmet Food"
              className="w-full h-[400px] object-cover opacity-50 rounded"
            />
            <h1 className="absolute inset-0 flex items-center justify-center font-['Press_Start_2P'] text-[50px] leading-[1.5] text-white px-8">
              Diseñada por ti,<br />
              perfeccionada por el fuego.
            </h1>
          </div>

          <div className="border-t border-b border-white py-8 my-12">
            <p className="font-['Average_Sans'] text-[40px] mb-6">Cyber-Gourmet</p>
            <p className="font-['Average_Sans'] text-[20px] max-w-[900px] mx-auto leading-relaxed">
              En Cyber-gourmet, hemos desbloqueado el siguiente nivel de la gastronomía urbana. No creemos en los menús cerrados, creemos en tu capacidad para crear el arma definitiva contra el hambre. Combinamos ingredientes frescos con la estética de un futuro neón para que cada bocado sea una experiencia inmersiva. ¿Estás listo para hackear tu cena?
            </p>
          </div>
        </div>
      </section>

      {/* Info Section */}
      <section className="py-8 bg-black">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl">
            <div className="space-y-6">
              <button className="w-full border-2 border-[#CD2E2E] bg-black py-4 px-6 font-['Press_Start_2P'] text-[20px] text-white hover:bg-[#CD2E2E] hover:text-black transition-colors text-left flex items-center gap-4">
                <div className="w-4 h-4 bg-[#CD2E2E] rotate-45"></div>
                Top Players
              </button>
              <button className="w-full border-2 border-[#CD2E2E] bg-black py-4 px-6 font-['Press_Start_2P'] text-[20px] text-white hover:bg-[#CD2E2E] hover:text-black transition-colors text-left flex items-center gap-4">
                <div className="w-4 h-4 bg-[#CD2E2E] rotate-45"></div>
                Daily Quests
              </button>
              <button className="w-full border-2 border-[#CD2E2E] bg-black py-4 px-6 font-['Press_Start_2P'] text-[20px] text-white hover:bg-[#CD2E2E] hover:text-black transition-colors text-left flex items-center gap-4">
                <div className="w-4 h-4 bg-[#CD2E2E] rotate-45"></div>
                Build Mode
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-16 bg-black">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-3 gap-8">
            <div className="relative">
              <img src={imgFood1} alt="Cyber burger" className="w-full h-[295px] object-cover rounded shadow-lg" />
              <button className="bg-[#46b96e] border border-black h-[136px] w-full -mt-8 relative z-10 font-['Press_Start_2P'] text-[18px] text-black hover:bg-[#3da65d] transition-colors flex items-center justify-center">
                Level: Artisan.
              </button>
            </div>
            <div className="relative">
              <img src={imgFood2} alt="Neon drinks" className="w-full h-[293px] object-cover rounded shadow-lg" />
              <button className="bg-[#46b96e] border border-black h-[136px] w-full -mt-8 relative z-10 font-['Press_Start_2P'] text-[18px] text-black hover:bg-[#3da65d] transition-colors flex items-center justify-center">
                The Lobby.
              </button>
            </div>
            <div className="relative">
              <img src={imgFood3} alt="Cyber food" className="w-full h-[293px] object-cover rounded shadow-lg" />
              <button className="bg-[#46b96e] border border-black h-[136px] w-full -mt-8 relative z-10 font-['Press_Start_2P'] text-[18px] text-black hover:bg-[#3da65d] transition-colors flex items-center justify-center">
                Full Loadout.
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#572364] py-12 mt-20">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-start">
            {/* Columna Izquierda */}
            <div className="flex flex-col gap-4 w-1/3">
              <button className="bg-[#572364] px-6 py-3 font-['Average_Sans'] text-[20px] border border-white hover:bg-[#6b2d7a] transition-colors flex items-center gap-3 w-fit">
                <div className="w-6 h-6">
                  <ExternalLink />
                </div>
                Compartir
              </button>
              <button className="bg-[#572364] px-6 py-3 font-['Average_Sans'] text-[20px] border border-white hover:bg-[#6b2d7a] transition-colors flex items-center gap-3 w-fit">
                <div className="w-6 h-6">
                  <Link />
                </div>
                Enlace
              </button>
              <button className="bg-[#572364] px-6 py-3 font-['Average_Sans'] text-[20px] border border-white hover:bg-[#6b2d7a] transition-colors flex items-center gap-3 w-fit">
                <div className="w-6 h-6">
                  <LocationMarker />
                </div>
                Ubicación
              </button>
            </div>

            {/* Logo Central */}
            <div className="flex items-center justify-center w-1/3">
              <div className="h-[120px] w-[120px]">
                <LogoFooter />
              </div>
            </div>

            {/* Columna Derecha */}
            <div className="flex flex-col gap-4 w-1/3 items-end">
              <button className="bg-[#572364] px-6 py-3 font-['Average_Sans'] text-[20px] border border-white hover:bg-[#6b2d7a] transition-colors flex items-center gap-3 w-fit">
                <div className="w-6 h-6">
                  <Phone />
                </div>
                Teléfono
              </button>
              <button className="bg-[#572364] px-6 py-3 font-['Average_Sans'] text-[20px] border border-white hover:bg-[#6b2d7a] transition-colors flex items-center gap-3 w-fit">
                <div className="w-6 h-6">
                  <Mail />
                </div>
                Email
              </button>
              <button className="bg-[#572364] px-6 py-3 font-['Average_Sans'] text-[20px] border border-white hover:bg-[#6b2d7a] transition-colors flex items-center gap-3 w-fit">
                <div className="w-6 h-6">
                  <Annotation />
                </div>
                Comentarios
              </button>
            </div>
          </div>

          <div className="text-center mt-8">
            <p className="font-['Average_Sans'] text-[18px]">
              © 2026 Cyber-Gourmet S.L. Todos los derechos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}