import svgPaths from "./svg-4hnm4cnoth";
import imgImageCyberGourmetLogo from "./a989c9088a9b92c5e224205202d8c79f33d34c47.png";
import imgImageCyberGourmetFood from "./1620db19378180dd57c01750022c56887dd6cd3d.png";
import imgImageCyberBurger from "./caea84ae638c0685467a255ed8817c7bd4f7fb50.png";
import imgImageNeonDrinks from "./511e6668ef00f09bf40760217c05ed03bc88ae2f.png";
import imgImageCyberFood from "./d18c2ab4d37bfa9500f3a2210520c0567e470f9e.png";
import imgImage from "./4e911018752c850edcc1b9e83c48b1ec496024e2.png";

function ImageCyberGourmetLogo() {
  return (
    <div className="h-[80px] relative rounded-[4px] shrink-0 w-[82px]" data-name="Image (Cyber-Gourmet Logo)">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none rounded-[4px] size-full" src={imgImageCyberGourmetLogo} />
    </div>
  );
}

function Container2() {
  return (
    <div className="absolute h-[42px] left-[16px] top-[27px] w-[19.163px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['Inter:Regular','Noto_Sans_Math:Regular',sans-serif] font-normal leading-[42px] left-0 not-italic text-[28px] text-white top-[-2.4px] whitespace-nowrap">≡</p>
      </div>
    </div>
  );
}

function Container5() {
  return <div className="bg-black h-[30px] relative rounded-[4px] shrink-0 w-[250px]" data-name="Container" />;
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p107a080} id="Vector" stroke="var(--stroke-0, black)" strokeWidth="1.33333" />
          <path d="M14 14L11.1 11.1" id="Vector_2" stroke="var(--stroke-0, black)" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#d1a0de] relative rounded-[4px] shrink-0 size-[30px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon />
      </div>
    </div>
  );
}

function Container4() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[4px] items-center relative size-full">
        <Container5 />
        <Button />
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="h-[21.125px] relative shrink-0 w-[23.15px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.15 21.125">
        <g clipPath="url(#clip0_10_163)" id="Icon">
          <path d={svgPaths.pda91a00} id="Vector" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.14967" />
        </g>
        <defs>
          <clipPath id="clip0_10_163">
            <rect fill="white" height="21.125" width="23.15" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[-0.58px] top-[-0.56px]" data-name="Container">
      <Icon1 />
    </div>
  );
}

function Container6() {
  return (
    <div className="h-[20px] relative shrink-0 w-[22px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container7 />
      </div>
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-white relative rounded-[4px] shrink-0 size-[30px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Container6 />
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="absolute left-[1150.8px] top-[33px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Container4 />
        <Button1 />
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center py-[8px] relative size-full">
        <ImageCyberGourmetLogo />
        <Container2 />
        <Container3 />
      </div>
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-[#572364] flex-[248.125_0_0] h-full min-w-px relative" data-name="Button">
      <div aria-hidden className="absolute border-black border-l-[0.8px] border-r-[0.8px] border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Press_Start_2P:Regular',sans-serif] leading-[21px] left-[124.06px] not-italic text-[14px] text-center text-white top-[15.2px] whitespace-nowrap">CARTA</p>
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="bg-[#572364] flex-[248.137_0_0] h-full min-w-px relative" data-name="Button">
      <div aria-hidden className="absolute border-black border-l-[0.8px] border-r-[0.8px] border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Press_Start_2P:Regular',sans-serif] leading-[21px] left-[124.06px] not-italic text-[14px] text-center text-white top-[15.2px] whitespace-nowrap">PEDIDO</p>
      </div>
    </div>
  );
}

function Button4() {
  return (
    <div className="bg-[#572364] flex-[248.125_0_0] h-full min-w-px relative" data-name="Button">
      <div aria-hidden className="absolute border-black border-l-[0.8px] border-r-[0.8px] border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Press_Start_2P:Regular',sans-serif] leading-[21px] left-[124.06px] not-italic text-[14px] text-center text-white top-[15.2px] whitespace-nowrap">PERSONALIZACIÓN</p>
      </div>
    </div>
  );
}

function Button5() {
  return (
    <div className="bg-[#572364] flex-[248.137_0_0] h-full min-w-px relative" data-name="Button">
      <div aria-hidden className="absolute border-black border-l-[0.8px] border-r-[0.8px] border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Press_Start_2P:Regular',sans-serif] leading-[21px] left-[124.06px] not-italic text-[14px] text-center text-white top-[15.2px] whitespace-nowrap">CONTACTO</p>
      </div>
    </div>
  );
}

function Button6() {
  return (
    <div className="bg-[#572364] flex-[248.137_0_0] h-full min-w-px relative" data-name="Button">
      <div aria-hidden className="absolute border-black border-l-[0.8px] border-r-[0.8px] border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Press_Start_2P:Regular',sans-serif] leading-[21px] left-[124.06px] not-italic text-[14px] text-center text-white top-[15.2px] whitespace-nowrap">SOBRE NOSOTROS</p>
      </div>
    </div>
  );
}

function Button7() {
  return (
    <div className="bg-[#572364] flex-[248.137_0_0] h-full min-w-px relative" data-name="Button">
      <div aria-hidden className="absolute border-black border-l-[0.8px] border-r-[0.8px] border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Press_Start_2P:Regular',sans-serif] leading-[21px] left-[124.06px] not-italic text-[14px] text-center text-white top-[15.2px] whitespace-nowrap">RESERVAR</p>
      </div>
    </div>
  );
}

function Navigation() {
  return (
    <div className="absolute content-stretch flex h-[53.8px] items-start left-[-16px] pt-[0.8px] top-0 w-[1488.8px]" data-name="Navigation">
      <div aria-hidden className="absolute border-black border-solid border-t-[0.8px] inset-0 pointer-events-none" />
      <Button2 />
      <Button3 />
      <Button4 />
      <Button5 />
      <Button6 />
      <Button7 />
    </div>
  );
}

function NavigationNegativeMargin() {
  return (
    <div className="h-[53.8px] relative shrink-0 w-[1456.8px]" data-name="Navigation (negative margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Navigation />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="max-w-[1536px] relative shrink-0 w-[1520.8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start max-w-[inherit] px-[16px] relative size-full">
        <Container1 />
        <NavigationNegativeMargin />
      </div>
    </div>
  );
}

function Header() {
  return (
    <div className="bg-[#572364] relative shrink-0 w-full" data-name="Header">
      <div aria-hidden className="absolute border-b-[0.8px] border-black border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-[0.8px] relative size-full">
        <Container />
      </div>
    </div>
  );
}

function ImageCyberGourmetFood() {
  return (
    <div className="h-[400px] opacity-50 relative rounded-[4px] shrink-0 w-full" data-name="Image (Cyber Gourmet Food)">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none rounded-[4px] size-full" src={imgImageCyberGourmetFood} />
    </div>
  );
}

function Heading() {
  return (
    <div className="absolute h-[400px] left-0 top-0" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[32px] relative size-full">
        <div className="[word-break:break-word] font-['Press_Start_2P:Regular',sans-serif] leading-[0] not-italic relative shrink-0 text-[50px] text-center text-white w-[836px]">
          <p className="leading-[75px] mb-0">Diseñada por ti,</p>
          <p className="leading-[75px]">perfeccionada por el fuego.</p>
        </div>
      </div>
    </div>
  );
}

function Container9() {
  return (
    <div className="content-stretch flex flex-col items-start max-w-[900px] relative shrink-0 w-[900px]" data-name="Container">
      <ImageCyberGourmetFood />
      <Heading />
    </div>
  );
}

function ContainerMargin() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-center relative size-full">
        <Container9 />
      </div>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="relative shrink-0 w-full" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-center relative size-full">
        <p className="[word-break:break-word] font-['Average_Sans:Regular',sans-serif] leading-[60px] not-italic relative shrink-0 text-[40px] text-center text-white whitespace-nowrap">Cyber-Gourmet</p>
      </div>
    </div>
  );
}

function App1() {
  return (
    <div className="relative shrink-0 w-full" data-name="App">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-center pb-[0.6px] pt-[23.4px] relative size-full">
        <p className="[word-break:break-word] font-['Average_Sans:Regular',sans-serif] leading-[32.5px] not-italic relative shrink-0 text-[20px] text-center text-white w-[900px]">En Cyber-gourmet, hemos desbloqueado el siguiente nivel de la gastronomía urbana. No creemos en los menús cerrados, creemos en tu capacidad para crear el arma definitiva contra el hambre. Combinamos ingredientes frescos con la estética de un futuro neón para que cada bocado sea una experiencia inmersiva. ¿Estás listo para hackear tu cena?</p>
      </div>
    </div>
  );
}

function Container10() {
  return (
    <div className="content-stretch flex flex-col items-start py-[32.8px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden className="absolute border-b-[0.8px] border-solid border-t-[0.8px] border-white inset-0 pointer-events-none" />
      <Paragraph />
      <App1 />
    </div>
  );
}

function ContainerMargin1() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[48px] relative size-full">
        <Container10 />
      </div>
    </div>
  );
}

function Container8() {
  return (
    <div className="max-w-[1536px] relative shrink-0 w-[1520.8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start max-w-[inherit] pb-[48px] px-[16px] relative size-full">
        <ContainerMargin />
        <ContainerMargin1 />
      </div>
    </div>
  );
}

function Section() {
  return (
    <div className="relative shrink-0 w-full" data-name="Section">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start py-[80px] relative size-full">
        <Container8 />
      </div>
    </div>
  );
}

function Container13() {
  return <div className="bg-[#cd2e2e] relative size-[16px]" data-name="Container" />;
}

function ContainerTransform() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Container (transform)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <div className="absolute flex items-center justify-center left-[-3.31px] size-[22.627px] top-[-3.31px]">
          <div className="flex-none rotate-45">
            <Container13 />
          </div>
        </div>
      </div>
    </div>
  );
}

function Button8() {
  return (
    <div className="bg-black h-[65.2px] relative shrink-0 w-[896px]" data-name="Button">
      <div aria-hidden className="absolute border-[#cd2e2e] border-[1.6px] border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-center px-[25.6px] py-[17.6px] relative size-full">
        <ContainerTransform />
        <p className="[word-break:break-word] font-['Press_Start_2P:Regular',sans-serif] leading-[30px] not-italic relative shrink-0 text-[20px] text-white whitespace-nowrap">Top Players</p>
      </div>
    </div>
  );
}

function Container14() {
  return <div className="bg-[#cd2e2e] relative size-[16px]" data-name="Container" />;
}

function ContainerTransform1() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Container (transform)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <div className="absolute flex items-center justify-center left-[-3.31px] size-[22.627px] top-[-3.31px]">
          <div className="flex-none rotate-45">
            <Container14 />
          </div>
        </div>
      </div>
    </div>
  );
}

function Button9() {
  return (
    <div className="bg-black content-stretch flex gap-[16px] h-[65.2px] items-center px-[25.6px] py-[17.6px] relative shrink-0 w-[896px]" data-name="Button">
      <div aria-hidden className="absolute border-[#cd2e2e] border-[1.6px] border-solid inset-0 pointer-events-none" />
      <ContainerTransform1 />
      <p className="[word-break:break-word] font-['Press_Start_2P:Regular',sans-serif] leading-[30px] not-italic relative shrink-0 text-[20px] text-white whitespace-nowrap">Daily Quests</p>
    </div>
  );
}

function ButtonMargin() {
  return (
    <div className="relative shrink-0" data-name="Button (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[24px] relative size-full">
        <Button9 />
      </div>
    </div>
  );
}

function Container15() {
  return <div className="bg-[#cd2e2e] relative size-[16px]" data-name="Container" />;
}

function ContainerTransform2() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Container (transform)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <div className="absolute flex items-center justify-center left-[-3.31px] size-[22.627px] top-[-3.31px]">
          <div className="flex-none rotate-45">
            <Container15 />
          </div>
        </div>
      </div>
    </div>
  );
}

function Button10() {
  return (
    <div className="bg-black content-stretch flex gap-[16px] h-[65.2px] items-center px-[25.6px] py-[17.6px] relative shrink-0 w-[896px]" data-name="Button">
      <div aria-hidden className="absolute border-[#cd2e2e] border-[1.6px] border-solid inset-0 pointer-events-none" />
      <ContainerTransform2 />
      <p className="[word-break:break-word] font-['Press_Start_2P:Regular',sans-serif] leading-[30px] not-italic relative shrink-0 text-[20px] text-white whitespace-nowrap">Build Mode</p>
    </div>
  );
}

function ButtonMargin1() {
  return (
    <div className="relative shrink-0" data-name="Button (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[24px] relative size-full">
        <Button10 />
      </div>
    </div>
  );
}

function Container12() {
  return (
    <div className="max-w-[896px] relative shrink-0 w-[896px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start max-w-[inherit] relative size-full">
        <Button8 />
        <ButtonMargin />
        <ButtonMargin1 />
      </div>
    </div>
  );
}

function Container11() {
  return (
    <div className="max-w-[1536px] relative shrink-0 w-[1520.8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start max-w-[inherit] px-[16px] relative size-full">
        <Container12 />
      </div>
    </div>
  );
}

function Section1() {
  return (
    <div className="bg-black relative shrink-0 w-full" data-name="Section">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start py-[32px] relative size-full">
        <Container11 />
      </div>
    </div>
  );
}

function ImageCyberBurger() {
  return (
    <div className="h-[295px] relative rounded-[4px] shadow-[0px_10px_15px_-3px_rgba(0,0,0,0.1),0px_4px_6px_-4px_rgba(0,0,0,0.1)] shrink-0 w-[474.925px]" data-name="Image (Cyber burger)">
      <div aria-hidden className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 pointer-events-none rounded-[4px]">
        <div className="absolute bg-[rgba(255,255,255,0)] bg-clip-padding border-0 border-[transparent] border-solid inset-0 rounded-[4px]" />
        <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid max-w-none object-cover rounded-[4px] size-full" src={imgImageCyberBurger} />
      </div>
    </div>
  );
}

function Button11() {
  return (
    <div className="absolute bg-[#46b96e] content-stretch flex h-[136px] items-center justify-center left-0 p-[0.8px] top-[-32px] w-[474.925px]" data-name="Button">
      <div aria-hidden className="absolute border-[0.8px] border-black border-solid inset-0 pointer-events-none" />
      <p className="[word-break:break-word] font-['Press_Start_2P:Regular',sans-serif] leading-[27px] not-italic relative shrink-0 text-[18px] text-black text-center whitespace-nowrap">Level: Artisan.</p>
    </div>
  );
}

function ButtonNegativeMargin() {
  return (
    <div className="h-[104px] relative shrink-0 w-[474.925px]" data-name="Button (negative margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Button11 />
      </div>
    </div>
  );
}

function Container18() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-0 top-0" data-name="Container">
      <ImageCyberBurger />
      <ButtonNegativeMargin />
    </div>
  );
}

function ImageNeonDrinks() {
  return (
    <div className="h-[293px] relative rounded-[4px] shadow-[0px_10px_15px_-3px_rgba(0,0,0,0.1),0px_4px_6px_-4px_rgba(0,0,0,0.1)] shrink-0 w-[474.938px]" data-name="Image (Neon drinks)">
      <div aria-hidden className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 pointer-events-none rounded-[4px]">
        <div className="absolute bg-[rgba(255,255,255,0)] bg-clip-padding border-0 border-[transparent] border-solid inset-0 rounded-[4px]" />
        <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid max-w-none object-cover rounded-[4px] size-full" src={imgImageNeonDrinks} />
      </div>
    </div>
  );
}

function Button12() {
  return (
    <div className="absolute bg-[#46b96e] content-stretch flex h-[136px] items-center justify-center left-0 p-[0.8px] top-[-32px] w-[474.938px]" data-name="Button">
      <div aria-hidden className="absolute border-[0.8px] border-black border-solid inset-0 pointer-events-none" />
      <p className="[word-break:break-word] font-['Press_Start_2P:Regular',sans-serif] leading-[27px] not-italic relative shrink-0 text-[18px] text-black text-center whitespace-nowrap">The Lobby.</p>
    </div>
  );
}

function ButtonNegativeMargin1() {
  return (
    <div className="h-[104px] relative shrink-0 w-[474.938px]" data-name="Button (negative margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Button12 />
      </div>
    </div>
  );
}

function Container19() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[506.92px] top-0" data-name="Container">
      <ImageNeonDrinks />
      <ButtonNegativeMargin1 />
    </div>
  );
}

function ImageCyberFood() {
  return (
    <div className="h-[293px] relative rounded-[4px] shadow-[0px_10px_15px_-3px_rgba(0,0,0,0.1),0px_4px_6px_-4px_rgba(0,0,0,0.1)] shrink-0 w-[474.938px]" data-name="Image (Cyber food)">
      <div aria-hidden className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 pointer-events-none rounded-[4px]">
        <div className="absolute bg-[rgba(255,255,255,0)] bg-clip-padding border-0 border-[transparent] border-solid inset-0 rounded-[4px]" />
        <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid max-w-none object-cover rounded-[4px] size-full" src={imgImageCyberFood} />
      </div>
    </div>
  );
}

function Button13() {
  return (
    <div className="absolute bg-[#46b96e] content-stretch flex h-[136px] items-center justify-center left-0 p-[0.8px] top-[-32px] w-[474.938px]" data-name="Button">
      <div aria-hidden className="absolute border-[0.8px] border-black border-solid inset-0 pointer-events-none" />
      <p className="[word-break:break-word] font-['Press_Start_2P:Regular',sans-serif] leading-[27px] not-italic relative shrink-0 text-[18px] text-black text-center whitespace-nowrap">Full Loadout.</p>
    </div>
  );
}

function ButtonNegativeMargin2() {
  return (
    <div className="h-[104px] relative shrink-0 w-[474.938px]" data-name="Button (negative margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Button13 />
      </div>
    </div>
  );
}

function Container20() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[1013.86px] top-0" data-name="Container">
      <ImageCyberFood />
      <ButtonNegativeMargin2 />
    </div>
  );
}

function Container17() {
  return (
    <div className="h-[399px] relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container18 />
        <Container19 />
        <Container20 />
      </div>
    </div>
  );
}

function Container16() {
  return (
    <div className="max-w-[1536px] relative shrink-0 w-[1520.8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start max-w-[inherit] px-[16px] relative size-full">
        <Container17 />
      </div>
    </div>
  );
}

function Section2() {
  return (
    <div className="bg-black relative shrink-0 w-full" data-name="Section">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start py-[64px] relative size-full">
        <Container16 />
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[16.875px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.875 16.875">
        <g clipPath="url(#clip0_10_157)" id="Icon">
          <path d={svgPaths.pb653780} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.888158" />
        </g>
        <defs>
          <clipPath id="clip0_10_157">
            <rect fill="white" height="16.875" width="16.875" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container25() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[3.56px] top-[3.56px]" data-name="Container">
      <Icon2 />
    </div>
  );
}

function Container24() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container25 />
      </div>
    </div>
  );
}

function Button14() {
  return (
    <div className="bg-[#572364] relative shrink-0 w-[168.75px]" data-name="Button">
      <div aria-hidden className="absolute border-[0.8px] border-solid border-white inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center px-[24.8px] py-[12.8px] relative size-full">
        <Container24 />
        <p className="[word-break:break-word] font-['Average_Sans:Regular',sans-serif] leading-[30px] not-italic relative shrink-0 text-[20px] text-center text-white whitespace-nowrap">Compartir</p>
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[18.837px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.8375 18.8375">
        <g clipPath="url(#clip0_10_151)" id="Icon">
          <path d={svgPaths.p2baa2e00} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.841899" />
        </g>
        <defs>
          <clipPath id="clip0_10_151">
            <rect fill="white" height="18.8375" width="18.8375" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container27() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[2.54px] top-[2.63px]" data-name="Container">
      <Icon3 />
    </div>
  );
}

function Container26() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container27 />
      </div>
    </div>
  );
}

function Button15() {
  return (
    <div className="bg-[#572364] relative shrink-0 w-[138.5px]" data-name="Button">
      <div aria-hidden className="absolute border-[0.8px] border-solid border-white inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center px-[24.8px] py-[12.8px] relative size-full">
        <Container26 />
        <p className="[word-break:break-word] font-['Average_Sans:Regular',sans-serif] leading-[30px] not-italic relative shrink-0 text-[20px] text-center text-white whitespace-nowrap">Enlace</p>
      </div>
    </div>
  );
}

function Icon4() {
  return (
    <div className="h-[19.188px] relative shrink-0 w-[16.7px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.7 19.1875">
        <g clipPath="url(#clip0_10_160)" id="Icon">
          <path d={svgPaths.p23d6a980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.715795" />
        </g>
        <defs>
          <clipPath id="clip0_10_160">
            <rect fill="white" height="19.1875" width="16.7" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container29() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[3.65px] top-[2.65px]" data-name="Container">
      <Icon4 />
    </div>
  );
}

function Icon5() {
  return (
    <div className="h-[6.713px] relative shrink-0 w-[6.7px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6.7 6.7125">
        <g clipPath="url(#clip0_10_170)" id="Icon">
          <path d={svgPaths.p8ef85c0} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.715333" />
        </g>
        <defs>
          <clipPath id="clip0_10_170">
            <rect fill="white" height="6.7125" width="6.7" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container30() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[8.65px] top-[7.64px]" data-name="Container">
      <Icon5 />
    </div>
  );
}

function Container28() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container29 />
        <Container30 />
      </div>
    </div>
  );
}

function Button16() {
  return (
    <div className="bg-[#572364] relative shrink-0 w-[166px]" data-name="Button">
      <div aria-hidden className="absolute border-[0.8px] border-solid border-white inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center px-[24.8px] py-[12.8px] relative size-full">
        <Container28 />
        <p className="[word-break:break-word] font-['Average_Sans:Regular',sans-serif] leading-[30px] not-italic relative shrink-0 text-[20px] text-center text-white whitespace-nowrap">Ubicación</p>
      </div>
    </div>
  );
}

function Container23() {
  return (
    <div className="relative shrink-0 w-[496.263px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[16px] items-start relative size-full">
        <Button14 />
        <Button15 />
        <Button16 />
      </div>
    </div>
  );
}

function Container33() {
  return <div className="absolute bg-white left-0 rounded-[4px] size-[120px] top-0" data-name="Container" />;
}

function Image() {
  return (
    <div className="absolute h-[175.075px] left-[-27.63px] top-[-23.7px] w-[319.738px]" data-name="Image">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage} />
    </div>
  );
}

function Container34() {
  return (
    <div className="absolute left-0 overflow-clip rounded-[4px] size-[120px] top-0" data-name="Container">
      <Image />
    </div>
  );
}

function Container35() {
  return <div className="absolute bg-[rgba(255,255,255,0)] border-8 border-[rgba(255,255,255,0)] border-solid left-[-8px] rounded-[12px] shadow-[0px_0px_0px_0px_rgba(0,0,0,0.2),0px_0px_2px_0px_rgba(0,0,0,0.08),0px_2px_6px_0px_rgba(0,0,0,0.1)] size-[136px] top-[-8px]" data-name="Container" />;
}

function Container32() {
  return (
    <div className="relative rounded-[4px] shrink-0 size-[120px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container33 />
        <Container34 />
        <Container35 />
      </div>
    </div>
  );
}

function Container31() {
  return (
    <div className="relative shrink-0 w-[496.263px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Container32 />
      </div>
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[18.75px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.75 18.75">
        <g clipPath="url(#clip0_10_173)" id="Icon">
          <path d={svgPaths.p37e5c100} id="Vector" stroke="var(--stroke-0, #F7EEEF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.767286" />
        </g>
        <defs>
          <clipPath id="clip0_10_173">
            <rect fill="white" height="18.75" width="18.75" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container38() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[2.63px] top-[2.63px]" data-name="Container">
      <Icon6 />
    </div>
  );
}

function Container37() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container38 />
      </div>
    </div>
  );
}

function Button17() {
  return (
    <div className="bg-[#572364] relative shrink-0 w-[154.188px]" data-name="Button">
      <div aria-hidden className="absolute border-[0.8px] border-solid border-white inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center px-[24.8px] py-[12.8px] relative size-full">
        <Container37 />
        <p className="[word-break:break-word] font-['Average_Sans:Regular',sans-serif] leading-[30px] not-italic relative shrink-0 text-[20px] text-center text-white whitespace-nowrap">Teléfono</p>
      </div>
    </div>
  );
}

function Icon7() {
  return (
    <div className="h-[14.7px] relative shrink-0 w-[18.55px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.55 14.7">
        <g clipPath="url(#clip0_10_154)" id="Icon">
          <path d={svgPaths.p12311900} id="Vector" stroke="var(--stroke-0, #F7EEEF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.62169" />
        </g>
        <defs>
          <clipPath id="clip0_10_154">
            <rect fill="white" height="14.7" width="18.55" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container40() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[2.72px] top-[4.65px]" data-name="Container">
      <Icon7 />
    </div>
  );
}

function Container39() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container40 />
      </div>
    </div>
  );
}

function Button18() {
  return (
    <div className="bg-[#572364] relative shrink-0 w-[131.288px]" data-name="Button">
      <div aria-hidden className="absolute border-[0.8px] border-solid border-white inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center px-[24.8px] py-[12.8px] relative size-full">
        <Container39 />
        <p className="[word-break:break-word] font-['Average_Sans:Regular',sans-serif] leading-[30px] not-italic relative shrink-0 text-[20px] text-center text-white whitespace-nowrap">Email</p>
      </div>
    </div>
  );
}

function Icon8() {
  return (
    <div className="h-[16.55px] relative shrink-0 w-[18.55px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.55 16.55">
        <g clipPath="url(#clip0_10_148)" id="Icon">
          <path d={svgPaths.pee14800} id="Vector" stroke="var(--stroke-0, #F7EEEF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.561041" />
        </g>
        <defs>
          <clipPath id="clip0_10_148">
            <rect fill="white" height="16.55" width="18.55" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container42() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[2.72px] top-[3.73px]" data-name="Container">
      <Icon8 />
    </div>
  );
}

function Container41() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container42 />
      </div>
    </div>
  );
}

function Button19() {
  return (
    <div className="bg-[#572364] relative shrink-0 w-[189.85px]" data-name="Button">
      <div aria-hidden className="absolute border-[0.8px] border-solid border-white inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center px-[24.8px] py-[12.8px] relative size-full">
        <Container41 />
        <p className="[word-break:break-word] font-['Average_Sans:Regular',sans-serif] leading-[30px] not-italic relative shrink-0 text-[20px] text-center text-white whitespace-nowrap">Comentarios</p>
      </div>
    </div>
  );
}

function Container36() {
  return (
    <div className="relative shrink-0 w-[496.263px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[16px] items-end relative size-full">
        <Button17 />
        <Button18 />
        <Button19 />
      </div>
    </div>
  );
}

function Container22() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <Container23 />
        <Container31 />
        <Container36 />
      </div>
    </div>
  );
}

function Container43() {
  return (
    <div className="h-[59px] relative shrink-0 w-[1488.8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-center pt-[32px] relative size-full">
        <p className="[word-break:break-word] font-['Average_Sans:Regular',sans-serif] leading-[27px] not-italic relative shrink-0 text-[18px] text-center text-white whitespace-nowrap">© 2026 Cyber-Gourmet S.L. Todos los derechos reservados.</p>
      </div>
    </div>
  );
}

function Container21() {
  return (
    <div className="max-w-[1536px] relative shrink-0 w-[1520.8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start max-w-[inherit] px-[16px] relative size-full">
        <Container22 />
        <Container43 />
      </div>
    </div>
  );
}

function Footer() {
  return (
    <div className="bg-[#572364] content-stretch flex flex-col items-start py-[48px] relative shrink-0 w-full" data-name="Footer">
      <Container21 />
    </div>
  );
}

function FooterMargin() {
  return (
    <div className="relative shrink-0 w-full" data-name="Footer (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[80px] relative size-full">
        <Footer />
      </div>
    </div>
  );
}

function App() {
  return (
    <div className="bg-black min-h-[730.4000244140625px] relative shrink-0 w-full" data-name="App">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start min-h-[inherit] relative size-full">
        <Header />
        <Section />
        <Section1 />
        <Section2 />
        <FooterMargin />
      </div>
    </div>
  );
}

function Body() {
  return (
    <div className="h-[730.4px] relative shrink-0 w-[1521px]" data-name="Body">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <App />
      </div>
    </div>
  );
}

export default function GourmetDinnerApp() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start relative size-full" data-name="Gourmet Dinner App">
      <Body />
    </div>
  );
}