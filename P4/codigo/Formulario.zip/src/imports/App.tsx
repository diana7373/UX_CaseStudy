import { useState } from 'react';

export default function App() {
  const [selectedBread, setSelectedBread] = useState('classic');
  const [selectedMeat, setSelectedMeat] = useState('beef');
  const [selectedCheese, setSelectedCheese] = useState('cheddar');
  const [selectedToppings, setSelectedToppings] = useState<string[]>(['lettuce', 'tomato']);
  const [selectedSauces, setSelectedSauces] = useState<string[]>(['mayo']);
  const [spicyLevel, setSpicyLevel] = useState(50);

  const toggleTopping = (topping: string) => {
    setSelectedToppings(prev =>
      prev.includes(topping)
        ? prev.filter(t => t !== topping)
        : [...prev, topping]
    );
  };

  const toggleSauce = (sauce: string) => {
    setSelectedSauces(prev =>
      prev.includes(sauce)
        ? prev.filter(s => s !== sauce)
        : [...prev, sauce]
    );
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white overflow-x-hidden">
      {/* Hero Section */}
      <section className="container mx-auto px-6 py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <h1
              className="text-4xl md:text-5xl lg:text-6xl leading-tight"
              style={{ fontFamily: "'Press Start 2P', cursive" }}
            >
              <span className="text-[#d946ef] drop-shadow-[0_0_15px_rgba(217,70,239,0.8)]">
                Diseñada
              </span>{' '}
              <span className="text-white">por ti,</span><br />
              <span className="text-[#10b981] drop-shadow-[0_0_15px_rgba(16,185,129,0.8)]">
                perfeccionada
              </span>{' '}
              <span className="text-white">por el fuego.</span>
            </h1>

            <p
              className="text-lg md:text-xl text-gray-300 leading-relaxed max-w-xl"
              style={{ fontFamily: "'Inter', sans-serif" }}
            >
              Acabas de hackear el menú. Esto huele a victoria.
              <span className="text-[#ef4444]"> Asume el control</span> y crea tu obra maestra urbana.
            </p>

            <button
              className="bg-[#10b981] hover:bg-[#059669] text-black px-8 py-4 text-lg transition-all duration-300 shadow-[0_0_30px_rgba(16,185,129,0.6)] hover:shadow-[0_0_50px_rgba(16,185,129,0.9)] border-2 border-[#10b981]"
              style={{ fontFamily: "'Press Start 2P', cursive" }}
            >
              DOMINA EL MENÚ
            </button>
          </div>

          {/* Right Placeholder */}
          <div className="relative">
            <div className="aspect-square bg-gradient-to-br from-[#7c3aed]/20 to-[#10b981]/20 border-4 border-[#d946ef] shadow-[0_0_50px_rgba(217,70,239,0.5)] relative overflow-hidden">
              <div className="absolute inset-0 flex items-center justify-center p-8">
                <p
                  className="text-center text-sm md:text-base text-[#d946ef] leading-relaxed"
                  style={{ fontFamily: "'Press Start 2P', cursive" }}
                >
                  [Aquí iría un vídeo en bucle mostrando una hamburguesa con pan morado brillante en un entorno de luces de neón]
                </p>
              </div>
              {/* Neon Grid Effect */}
              <div className="absolute inset-0 opacity-20" style={{
                backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 19px, #10b981 19px, #10b981 20px), repeating-linear-gradient(90deg, transparent, transparent 19px, #10b981 19px, #10b981 20px)'
              }}></div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="container mx-auto px-6 py-16 lg:py-20">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Card 1 */}
          <div className="bg-[#1a1a1a] border-2 border-[#d946ef] p-8 shadow-[0_0_30px_rgba(217,70,239,0.3)] hover:shadow-[0_0_50px_rgba(217,70,239,0.6)] transition-all duration-300 relative group">
            <div className="absolute -top-1 -left-1 w-4 h-4 bg-[#d946ef]"></div>
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-[#d946ef]"></div>
            <div className="absolute -bottom-1 -left-1 w-4 h-4 bg-[#d946ef]"></div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-[#d946ef]"></div>

            <h3
              className="text-xl md:text-2xl mb-6 text-[#d946ef]"
              style={{ fontFamily: "'Press Start 2P', cursive" }}
            >
              Tú eres el Arquitecto
            </h3>
            <p
              className="text-gray-300 leading-relaxed"
              style={{ fontFamily: "'Inter', sans-serif" }}
            >
              Rompe las reglas. Elige cada ingrediente y diseña una hamburguesa que desafíe lo convencional.
            </p>
          </div>

          {/* Card 2 */}
          <div className="bg-[#1a1a1a] border-2 border-[#10b981] p-8 shadow-[0_0_30px_rgba(16,185,129,0.3)] hover:shadow-[0_0_50px_rgba(16,185,129,0.6)] transition-all duration-300 relative group">
            <div className="absolute -top-1 -left-1 w-4 h-4 bg-[#10b981]"></div>
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-[#10b981]"></div>
            <div className="absolute -bottom-1 -left-1 w-4 h-4 bg-[#10b981]"></div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-[#10b981]"></div>

            <h3
              className="text-xl md:text-2xl mb-6 text-[#10b981]"
              style={{ fontFamily: "'Press Start 2P', cursive" }}
            >
              Fuego y Neón
            </h3>
            <p
              className="text-gray-300 leading-relaxed"
              style={{ fontFamily: "'Inter', sans-serif" }}
            >
              La innovación técnica choca con la esencia artesanal. Carne a la parrilla de máxima calidad.
            </p>
          </div>

          {/* Card 3 */}
          <div className="bg-[#1a1a1a] border-2 border-[#ef4444] p-8 shadow-[0_0_30px_rgba(239,68,68,0.3)] hover:shadow-[0_0_50px_rgba(239,68,68,0.6)] transition-all duration-300 relative group">
            <div className="absolute -top-1 -left-1 w-4 h-4 bg-[#ef4444]"></div>
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-[#ef4444]"></div>
            <div className="absolute -bottom-1 -left-1 w-4 h-4 bg-[#ef4444]"></div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-[#ef4444]"></div>

            <h3
              className="text-xl md:text-2xl mb-6 text-[#ef4444]"
              style={{ fontFamily: "'Press Start 2P', cursive" }}
            >
              Sube de Nivel
            </h3>
            <p
              className="text-gray-300 leading-relaxed"
              style={{ fontFamily: "'Inter', sans-serif" }}
            >
              No solo se come. Se siente, se oye, se domina. Únete a la experiencia de sabor definitiva.
            </p>
          </div>
        </div>
      </section>

      {/* Burger Builder Section */}
      <section className="container mx-auto px-6 py-16 lg:py-20">
        <h2
          className="text-3xl md:text-5xl mb-4 text-center text-[#d946ef] drop-shadow-[0_0_15px_rgba(217,70,239,0.8)]"
          style={{ fontFamily: "'Press Start 2P', cursive" }}
        >
          Construye tu Arsenal
        </h2>
        <p
          className="text-center text-gray-400 mb-12 text-lg"
          style={{ fontFamily: "'Inter', sans-serif" }}
        >
          Hackea cada capa. Personaliza cada ingrediente. Domina tu creación.
        </p>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Left Side - Configuration Panel */}
          <div className="space-y-6">
            {/* Bread Selection */}
            <div className="bg-[#1a1a1a] border-2 border-[#d946ef] p-6 shadow-[0_0_30px_rgba(217,70,239,0.3)] relative">
              <div className="absolute -top-1 -left-1 w-3 h-3 bg-[#d946ef]"></div>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-[#d946ef]"></div>
              <div className="absolute -bottom-1 -left-1 w-3 h-3 bg-[#d946ef]"></div>
              <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-[#d946ef]"></div>

              <h3
                className="text-xl mb-4 text-[#d946ef]"
                style={{ fontFamily: "'Press Start 2P', cursive" }}
              >
                [PAN]
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { id: 'classic', name: 'Clásico', color: '#d946ef' },
                  { id: 'neon-purple', name: 'Neón Púrpura', color: '#d946ef' },
                  { id: 'charcoal', name: 'Carbón Negro', color: '#10b981' },
                  { id: 'sesame', name: 'Sésamo Dorado', color: '#ef4444' }
                ].map(bread => (
                  <button
                    key={bread.id}
                    onClick={() => setSelectedBread(bread.id)}
                    className={`px-4 py-3 border-2 transition-all duration-300 ${
                      selectedBread === bread.id
                        ? `bg-[${bread.color}]/20 border-[${bread.color}] shadow-[0_0_15px_rgba(217,70,239,0.6)]`
                        : 'bg-[#0a0a0a] border-gray-700 hover:border-[#d946ef]'
                    }`}
                    style={{ fontFamily: "'Inter', sans-serif" }}
                  >
                    {bread.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Meat Selection */}
            <div className="bg-[#1a1a1a] border-2 border-[#10b981] p-6 shadow-[0_0_30px_rgba(16,185,129,0.3)] relative">
              <div className="absolute -top-1 -left-1 w-3 h-3 bg-[#10b981]"></div>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-[#10b981]"></div>
              <div className="absolute -bottom-1 -left-1 w-3 h-3 bg-[#10b981]"></div>
              <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-[#10b981]"></div>

              <h3
                className="text-xl mb-4 text-[#10b981]"
                style={{ fontFamily: "'Press Start 2P', cursive" }}
              >
                [PROTEÍNA]
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { id: 'beef', name: 'Res Premium' },
                  { id: 'double-beef', name: 'Doble Res' },
                  { id: 'chicken', name: 'Pollo Crispy' },
                  { id: 'veggie', name: 'Vegetal X' }
                ].map(meat => (
                  <button
                    key={meat.id}
                    onClick={() => setSelectedMeat(meat.id)}
                    className={`px-4 py-3 border-2 transition-all duration-300 ${
                      selectedMeat === meat.id
                        ? 'bg-[#10b981]/20 border-[#10b981] shadow-[0_0_15px_rgba(16,185,129,0.6)]'
                        : 'bg-[#0a0a0a] border-gray-700 hover:border-[#10b981]'
                    }`}
                    style={{ fontFamily: "'Inter', sans-serif" }}
                  >
                    {meat.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Cheese Selection */}
            <div className="bg-[#1a1a1a] border-2 border-[#ef4444] p-6 shadow-[0_0_30px_rgba(239,68,68,0.3)] relative">
              <div className="absolute -top-1 -left-1 w-3 h-3 bg-[#ef4444]"></div>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-[#ef4444]"></div>
              <div className="absolute -bottom-1 -left-1 w-3 h-3 bg-[#ef4444]"></div>
              <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-[#ef4444]"></div>

              <h3
                className="text-xl mb-4 text-[#ef4444]"
                style={{ fontFamily: "'Press Start 2P', cursive" }}
              >
                [QUESO]
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { id: 'cheddar', name: 'Cheddar' },
                  { id: 'blue', name: 'Azul Intenso' },
                  { id: 'swiss', name: 'Suizo' },
                  { id: 'none', name: 'Sin Queso' }
                ].map(cheese => (
                  <button
                    key={cheese.id}
                    onClick={() => setSelectedCheese(cheese.id)}
                    className={`px-4 py-3 border-2 transition-all duration-300 ${
                      selectedCheese === cheese.id
                        ? 'bg-[#ef4444]/20 border-[#ef4444] shadow-[0_0_15px_rgba(239,68,68,0.6)]'
                        : 'bg-[#0a0a0a] border-gray-700 hover:border-[#ef4444]'
                    }`}
                    style={{ fontFamily: "'Inter', sans-serif" }}
                  >
                    {cheese.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Toppings - Multi-select */}
            <div className="bg-[#1a1a1a] border-2 border-[#d946ef] p-6 shadow-[0_0_30px_rgba(217,70,239,0.3)] relative">
              <div className="absolute -top-1 -left-1 w-3 h-3 bg-[#d946ef]"></div>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-[#d946ef]"></div>
              <div className="absolute -bottom-1 -left-1 w-3 h-3 bg-[#d946ef]"></div>
              <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-[#d946ef]"></div>

              <h3
                className="text-xl mb-4 text-[#d946ef]"
                style={{ fontFamily: "'Press Start 2P', cursive" }}
              >
                [TOPPINGS]
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { id: 'lettuce', name: '🥬 Lechuga' },
                  { id: 'tomato', name: '🍅 Tomate' },
                  { id: 'onion', name: '🧅 Cebolla' },
                  { id: 'pickle', name: '🥒 Pepinillo' },
                  { id: 'bacon', name: '🥓 Bacon' },
                  { id: 'avocado', name: '🥑 Aguacate' }
                ].map(topping => (
                  <button
                    key={topping.id}
                    onClick={() => toggleTopping(topping.id)}
                    className={`px-4 py-3 border-2 transition-all duration-300 ${
                      selectedToppings.includes(topping.id)
                        ? 'bg-[#d946ef]/20 border-[#d946ef] shadow-[0_0_15px_rgba(217,70,239,0.6)]'
                        : 'bg-[#0a0a0a] border-gray-700 hover:border-[#d946ef]'
                    }`}
                    style={{ fontFamily: "'Inter', sans-serif" }}
                  >
                    {topping.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Sauces - Multi-select */}
            <div className="bg-[#1a1a1a] border-2 border-[#10b981] p-6 shadow-[0_0_30px_rgba(16,185,129,0.3)] relative">
              <div className="absolute -top-1 -left-1 w-3 h-3 bg-[#10b981]"></div>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-[#10b981]"></div>
              <div className="absolute -bottom-1 -left-1 w-3 h-3 bg-[#10b981]"></div>
              <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-[#10b981]"></div>

              <h3
                className="text-xl mb-4 text-[#10b981]"
                style={{ fontFamily: "'Press Start 2P', cursive" }}
              >
                [SALSAS]
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { id: 'mayo', name: 'Mayonesa' },
                  { id: 'ketchup', name: 'Ketchup' },
                  { id: 'mustard', name: 'Mostaza' },
                  { id: 'bbq', name: 'BBQ Ahumada' },
                  { id: 'hot', name: 'Picante 🔥' },
                  { id: 'special', name: 'Especial Casa' }
                ].map(sauce => (
                  <button
                    key={sauce.id}
                    onClick={() => toggleSauce(sauce.id)}
                    className={`px-4 py-3 border-2 transition-all duration-300 ${
                      selectedSauces.includes(sauce.id)
                        ? 'bg-[#10b981]/20 border-[#10b981] shadow-[0_0_15px_rgba(16,185,129,0.6)]'
                        : 'bg-[#0a0a0a] border-gray-700 hover:border-[#10b981]'
                    }`}
                    style={{ fontFamily: "'Inter', sans-serif" }}
                  >
                    {sauce.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Spicy Level Slider */}
            <div className="bg-[#1a1a1a] border-2 border-[#ef4444] p-6 shadow-[0_0_30px_rgba(239,68,68,0.3)] relative">
              <div className="absolute -top-1 -left-1 w-3 h-3 bg-[#ef4444]"></div>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-[#ef4444]"></div>
              <div className="absolute -bottom-1 -left-1 w-3 h-3 bg-[#ef4444]"></div>
              <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-[#ef4444]"></div>

              <h3
                className="text-xl mb-4 text-[#ef4444]"
                style={{ fontFamily: "'Press Start 2P', cursive" }}
              >
                [NIVEL PICANTE]
              </h3>
              <div className="space-y-4">
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={spicyLevel}
                  onChange={(e) => setSpicyLevel(Number(e.target.value))}
                  className="w-full h-2 bg-[#0a0a0a] border-2 border-[#ef4444] appearance-none cursor-pointer accent-[#ef4444]"
                  style={{
                    background: `linear-gradient(to right, #ef4444 0%, #ef4444 ${spicyLevel}%, #0a0a0a ${spicyLevel}%, #0a0a0a 100%)`
                  }}
                />
                <div className="flex justify-between text-sm" style={{ fontFamily: "'Inter', sans-serif" }}>
                  <span className="text-gray-500">Suave</span>
                  <span className="text-[#ef4444] font-bold">{spicyLevel}%</span>
                  <span className="text-[#ef4444]">Extremo 🔥</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Side - Visual Preview */}
          <div className="sticky top-6">
            <div className="bg-[#1a1a1a] border-4 border-[#10b981] p-8 shadow-[0_0_50px_rgba(16,185,129,0.5)] relative">
              <div className="absolute -top-2 -left-2 w-6 h-6 bg-[#10b981]"></div>
              <div className="absolute -top-2 -right-2 w-6 h-6 bg-[#10b981]"></div>
              <div className="absolute -bottom-2 -left-2 w-6 h-6 bg-[#10b981]"></div>
              <div className="absolute -bottom-2 -right-2 w-6 h-6 bg-[#10b981]"></div>

              <h3
                className="text-2xl mb-6 text-center text-[#10b981]"
                style={{ fontFamily: "'Press Start 2P', cursive" }}
              >
                Tu Creación
              </h3>

              {/* Burger Layers Visualization */}
              <div className="space-y-2 mb-8">
                {/* Top Bun */}
                <div className="bg-gradient-to-r from-[#d946ef]/30 to-[#d946ef]/10 border-2 border-[#d946ef] p-3 text-center shadow-[0_0_10px_rgba(217,70,239,0.3)]">
                  <span style={{ fontFamily: "'Inter', sans-serif" }} className="text-sm text-[#d946ef]">
                    {selectedBread.toUpperCase()} (SUPERIOR)
                  </span>
                </div>

                {/* Sauces */}
                {selectedSauces.map((sauce, idx) => (
                  <div key={idx} className="bg-gradient-to-r from-[#10b981]/20 to-[#10b981]/5 border border-[#10b981] p-2 text-center">
                    <span style={{ fontFamily: "'Inter', sans-serif" }} className="text-xs text-[#10b981]">
                      {sauce.toUpperCase()}
                    </span>
                  </div>
                ))}

                {/* Toppings */}
                {selectedToppings.map((topping, idx) => (
                  <div key={idx} className="bg-gradient-to-r from-[#d946ef]/20 to-[#d946ef]/5 border border-[#d946ef] p-2 text-center">
                    <span style={{ fontFamily: "'Inter', sans-serif" }} className="text-xs text-[#d946ef]">
                      {topping.toUpperCase()}
                    </span>
                  </div>
                ))}

                {/* Cheese */}
                {selectedCheese !== 'none' && (
                  <div className="bg-gradient-to-r from-[#ef4444]/30 to-[#ef4444]/10 border-2 border-[#ef4444] p-3 text-center shadow-[0_0_10px_rgba(239,68,68,0.3)]">
                    <span style={{ fontFamily: "'Inter', sans-serif" }} className="text-sm text-[#ef4444]">
                      {selectedCheese.toUpperCase()}
                    </span>
                  </div>
                )}

                {/* Meat */}
                <div className="bg-gradient-to-r from-[#10b981]/40 to-[#10b981]/20 border-4 border-[#10b981] p-4 text-center shadow-[0_0_20px_rgba(16,185,129,0.5)]">
                  <span style={{ fontFamily: "'Press Start 2P', cursive" }} className="text-sm text-[#10b981]">
                    {selectedMeat.toUpperCase()}
                  </span>
                </div>

                {/* Bottom Bun */}
                <div className="bg-gradient-to-r from-[#d946ef]/30 to-[#d946ef]/10 border-2 border-[#d946ef] p-3 text-center shadow-[0_0_10px_rgba(217,70,239,0.3)]">
                  <span style={{ fontFamily: "'Inter', sans-serif" }} className="text-sm text-[#d946ef]">
                    {selectedBread.toUpperCase()} (BASE)
                  </span>
                </div>
              </div>

              {/* Stats */}
              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-sm" style={{ fontFamily: "'Inter', sans-serif" }}>
                  <span className="text-gray-400">Ingredientes:</span>
                  <span className="text-[#10b981]">{3 + selectedToppings.length + selectedSauces.length}</span>
                </div>
                <div className="flex justify-between text-sm" style={{ fontFamily: "'Inter', sans-serif" }}>
                  <span className="text-gray-400">Nivel Picante:</span>
                  <span className="text-[#ef4444]">{spicyLevel}%</span>
                </div>
                <div className="flex justify-between text-sm" style={{ fontFamily: "'Inter', sans-serif" }}>
                  <span className="text-gray-400">Estado:</span>
                  <span className="text-[#d946ef]">ACTIVO</span>
                </div>
              </div>

              {/* Order Button */}
              <button
                className="w-full bg-[#10b981] hover:bg-[#059669] text-black px-6 py-4 text-lg transition-all duration-300 shadow-[0_0_30px_rgba(16,185,129,0.6)] hover:shadow-[0_0_50px_rgba(16,185,129,0.9)] border-2 border-[#10b981]"
                style={{ fontFamily: "'Press Start 2P', cursive" }}
              >
                HACKEAR PEDIDO
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}