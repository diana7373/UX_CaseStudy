import imgImage8 from "./4e911018752c850edcc1b9e83c48b1ec496024e2.png";
import svgPaths from "./svg-77ilya2q3q";
type BotonFooterProps = {
  className?: string;
  texto?: string;
};

function BotonFooter({ className, texto = "Texto" }: BotonFooterProps) {
  return (
    <div className={className || "bg-[#572364] content-stretch flex items-center justify-center overflow-clip px-[53px] py-[7px] relative"} data-name="BotonFooter">
      <p className="[word-break:break-word] font-['Average_Sans:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[30px] text-white whitespace-nowrap">{texto}</p>
    </div>
  );
}

function LogoFooter({ className }: { className?: string }) {
  return (
    <div className={className || "h-[155.527px] relative w-[156px]"} data-name="LogoFooter">
      <div className="absolute inset-0 pointer-events-none rounded-[4px]" data-name="image 8">
        <div aria-hidden className="absolute inset-0 rounded-[4px]">
          <div className="absolute bg-white inset-0 rounded-[4px]" />
          <div className="absolute inset-0 overflow-hidden rounded-[4px]">
            <img alt="" className="absolute h-[145.9%] left-[-23.03%] max-w-none top-[-19.76%] w-[266.45%]" src={imgImage8} />
          </div>
        </div>
        <div aria-hidden className="absolute border-8 border-[rgba(255,255,255,0)] border-solid inset-[-8px] rounded-[12px] shadow-[0px_0px_0px_1px_rgba(0,0,0,0.2),0px_0px_2px_0px_rgba(0,0,0,0.08),0px_2px_6px_0px_rgba(0,0,0,0.1)]" />
      </div>
    </div>
  );
}

function Footer({ className }: { className?: string }) {
  return (
    <div className={className || "h-[351px] relative w-[2027px]"} data-name="Footer">
      <div className="absolute contents left-0 top-0">
        <div className="absolute h-[351px] left-0 top-0 w-[2027px]" data-name="Footer">
          <div className="absolute contents inset-0" data-name="Info section">
            <div className="absolute contents inset-0" data-name="Info background">
              <div className="absolute bg-[#572364] inset-0" data-name="Info section background" />
              <p className="[word-break:break-word] absolute font-['Average_Sans:Regular',sans-serif] inset-[76.64%_31.38%_13.68%_33.79%] leading-[normal] not-italic text-[30px] text-white">2026 Cyber-Gourmet S.L. Todos los derechos reservados.</p>
            </div>
            <div className="absolute aspect-[24/24] left-[4.34%] overflow-clip right-[92.99%] top-[59px]" data-name="external-link">
              <div className="absolute inset-[16.67%]" data-name="Vector">
                <div className="absolute inset-[-2.78%]">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 38 38">
                    <path d={svgPaths.p36cddc80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
          <div className="absolute flex inset-[10.26%_5.21%_64.61%_90.43%] items-center justify-center" style={{ containerType: "size" }}>
            <div className="flex-none h-[hypot(-46.9809cqw,-52.2213cqh)] rotate-138 w-[hypot(-53.0191cqw,47.7787cqh)]">
              <div className="overflow-clip relative size-full" data-name="phone">
                <div className="absolute inset-[12.5%]" data-name="Vector">
                  <div className="absolute inset-[-2.15%_-2.12%]">
                    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 49.25 48.5">
                      <path d={svgPaths.pc447980} id="Vector" stroke="var(--stroke-0, #F7EEEF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="absolute inset-[35.33%_5.43%_44.44%_90.43%] overflow-clip" data-name="mail">
            <div className="absolute inset-[20.83%_12.5%]" data-name="Vector">
              <div className="absolute inset-[-2.41%_-1.59%]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 65.0004 43.4167">
                  <path d={svgPaths.p2524700} id="Vector" stroke="var(--stroke-0, #F7EEEF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                </svg>
              </div>
            </div>
          </div>
          <div className="absolute aspect-[24/24] left-[4.34%] overflow-clip right-[92.85%] top-[137px]" data-name="link">
            <div className="absolute inset-[12.7%_12.7%_12.3%_12.3%]" data-name="Vector">
              <div className="absolute inset-[-2.34%]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 44.75 44.75">
                  <path d={svgPaths.p26bfb720} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                </svg>
              </div>
            </div>
          </div>
          <div className="absolute inset-[60.97%_5.28%_14.81%_90.48%] overflow-clip" data-name="annotation">
            <div className="absolute inset-[16.67%_12.5%]" data-name="Vector">
              <div className="absolute inset-[-1.76%_-1.55%]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 66.5 58.6667">
                  <path d={svgPaths.p1f00ba00} id="Vector" stroke="var(--stroke-0, #F7EEEF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                </svg>
              </div>
            </div>
          </div>
          <div className="absolute aspect-[24/24] left-[4.09%] overflow-clip right-[92.6%] top-[222px]" data-name="location-marker">
            <div className="absolute inset-[12.5%_16.67%_10.48%_16.67%]" data-name="Vector">
              <div className="absolute inset-[-1.94%_-2.24%]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 46.6667 53.6057">
                  <path d={svgPaths.p1b472300} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                </svg>
              </div>
            </div>
            <div className="absolute inset-[33.33%_37.5%_41.67%_37.5%]" data-name="Vector">
              <div className="absolute inset-[-5.97%]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.75 18.75">
                  <path d={svgPaths.p3081f780} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                </svg>
              </div>
            </div>
          </div>
          <p className="[word-break:break-word] absolute font-['Average_Sans:Regular',sans-serif] inset-[74.93%_66.16%_5.41%_31.33%] leading-[0] not-italic text-[0px] text-black">
            <span className="leading-[normal] text-[48px] text-white">©</span>
            <span className="leading-[normal] text-[30px]">{` `}</span>
          </p>
        </div>
        <div className="absolute contents left-[935px] top-[68px]">
          <LogoFooter className="absolute h-[155.527px] left-[935px] top-[68px] w-[156px]" />
        </div>
      </div>
      <BotonFooter className="absolute bg-[#572364] content-stretch flex items-center justify-center left-[150px] overflow-clip px-[53px] py-[7px] top-[59px]" texto="Compartir" />
      <BotonFooter className="absolute bg-[#572364] content-stretch flex items-center justify-center left-[1625px] overflow-clip px-[53px] py-[7px] top-[53px]" texto="Teléfono" />
      <BotonFooter className="absolute bg-[#572364] content-stretch flex items-center justify-center left-[1658px] overflow-clip px-[53px] py-[7px] top-[133px]" texto="Email" />
    </div>
  );
}

export default function Footer1({ className }: { className?: string }) {
  return (
    <div className={className || "h-[351px] relative w-[1931px]"} data-name="Footer">
      <div className="absolute contents left-0 top-0">
        <div className="absolute h-[351px] left-0 top-0 w-[2027px]" data-name="Footer">
          <div className="absolute contents inset-0" data-name="Info section">
            <div className="absolute contents inset-0" data-name="Info background">
              <div className="absolute bg-[#572364] inset-0" data-name="Info section background" />
              <p className="[word-break:break-word] absolute font-['Average_Sans:Regular',sans-serif] inset-[76.64%_31.38%_13.68%_33.79%] leading-[normal] not-italic text-[30px] text-white">2026 Cyber-Gourmet S.L. Todos los derechos reservados.</p>
            </div>
            <div className="absolute aspect-[24/24] left-[4.34%] overflow-clip right-[92.99%] top-[59px]" data-name="external-link">
              <div className="absolute inset-[16.67%]" data-name="Vector">
                <div className="absolute inset-[-2.78%]">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 38 38">
                    <path d={svgPaths.p36cddc80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
          <div className="absolute flex inset-[10.26%_5.21%_64.61%_90.43%] items-center justify-center" style={{ containerType: "size" }}>
            <div className="flex-none h-[hypot(-46.9809cqw,-52.2213cqh)] rotate-138 w-[hypot(-53.0191cqw,47.7787cqh)]">
              <div className="overflow-clip relative size-full" data-name="phone">
                <div className="absolute inset-[12.5%]" data-name="Vector">
                  <div className="absolute inset-[-2.15%_-2.12%]">
                    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 49.25 48.5">
                      <path d={svgPaths.pc447980} id="Vector" stroke="var(--stroke-0, #F7EEEF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="absolute inset-[35.33%_5.43%_44.44%_90.43%] overflow-clip" data-name="mail">
            <div className="absolute inset-[20.83%_12.5%]" data-name="Vector">
              <div className="absolute inset-[-2.41%_-1.59%]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 65.0004 43.4167">
                  <path d={svgPaths.p2524700} id="Vector" stroke="var(--stroke-0, #F7EEEF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                </svg>
              </div>
            </div>
          </div>
          <div className="absolute aspect-[24/24] left-[4.34%] overflow-clip right-[92.85%] top-[137px]" data-name="link">
            <div className="absolute inset-[12.7%_12.7%_12.3%_12.3%]" data-name="Vector">
              <div className="absolute inset-[-2.34%]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 44.75 44.75">
                  <path d={svgPaths.p26bfb720} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                </svg>
              </div>
            </div>
          </div>
          <div className="absolute inset-[60.97%_5.28%_14.81%_90.48%] overflow-clip" data-name="annotation">
            <div className="absolute inset-[16.67%_12.5%]" data-name="Vector">
              <div className="absolute inset-[-1.76%_-1.55%]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 66.5 58.6667">
                  <path d={svgPaths.p1f00ba00} id="Vector" stroke="var(--stroke-0, #F7EEEF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                </svg>
              </div>
            </div>
          </div>
          <div className="absolute aspect-[24/24] left-[4.09%] overflow-clip right-[92.6%] top-[222px]" data-name="location-marker">
            <div className="absolute inset-[12.5%_16.67%_10.48%_16.67%]" data-name="Vector">
              <div className="absolute inset-[-1.94%_-2.24%]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 46.6667 53.6057">
                  <path d={svgPaths.p1b472300} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                </svg>
              </div>
            </div>
            <div className="absolute inset-[33.33%_37.5%_41.67%_37.5%]" data-name="Vector">
              <div className="absolute inset-[-5.97%]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.75 18.75">
                  <path d={svgPaths.p3081f780} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                </svg>
              </div>
            </div>
          </div>
          <p className="[word-break:break-word] absolute font-['Average_Sans:Regular',sans-serif] inset-[74.93%_66.16%_5.41%_31.33%] leading-[0] not-italic text-[0px] text-black">
            <span className="leading-[normal] text-[48px] text-white">©</span>
            <span className="leading-[normal] text-[30px]">{` `}</span>
          </p>
        </div>
        <div className="absolute contents left-[935px] top-[68px]">
          <div className="absolute h-[155.527px] left-[935px] top-[68px] w-[156px]" data-name="LogoFooter">
            <div className="absolute inset-0 pointer-events-none rounded-[4px]" data-name="image 8">
              <div aria-hidden className="absolute inset-0 rounded-[4px]">
                <div className="absolute bg-white inset-0 rounded-[4px]" />
                <div className="absolute inset-0 overflow-hidden rounded-[4px]">
                  <img alt="" className="absolute h-[145.9%] left-[-23.03%] max-w-none top-[-19.76%] w-[266.45%]" src={imgImage8} />
                </div>
              </div>
              <div aria-hidden className="absolute border-8 border-[rgba(255,255,255,0)] border-solid inset-[-8px] rounded-[12px] shadow-[0px_0px_0px_1px_rgba(0,0,0,0.2),0px_0px_2px_0px_rgba(0,0,0,0.08),0px_2px_6px_0px_rgba(0,0,0,0.1)]" />
            </div>
          </div>
        </div>
      </div>
      <div className="absolute bg-[#572364] content-stretch flex items-center justify-center left-[150px] overflow-clip px-[53px] py-[7px] top-[59px]" data-name="BotonFooter">
        <p className="[word-break:break-word] font-['Average_Sans:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[30px] text-white whitespace-nowrap">Compartir</p>
      </div>
      <div className="absolute bg-[#572364] content-stretch flex items-center justify-center left-[1625px] overflow-clip px-[53px] py-[7px] top-[53px]" data-name="BotonFooter">
        <p className="[word-break:break-word] font-['Average_Sans:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[30px] text-white whitespace-nowrap">Teléfono</p>
      </div>
      <div className="absolute bg-[#572364] content-stretch flex items-center justify-center left-[1658px] overflow-clip px-[53px] py-[7px] top-[133px]" data-name="BotonFooter">
        <p className="[word-break:break-word] font-['Average_Sans:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[30px] text-white whitespace-nowrap">Email</p>
      </div>
      <BotonFooter className="absolute bg-[#572364] content-stretch flex inset-[42.45%_83.28%_42.45%_7.55%] items-center justify-center overflow-clip px-[53px] py-[7px]" texto="Enlace" />
      <BotonFooter className="absolute bg-[#572364] content-stretch flex inset-[66.67%_81.25%_18.23%_7.55%] items-center justify-center overflow-clip px-[53px] py-[7px]" texto="Ubicación" />
      <BotonFooter className="absolute bg-[#572364] content-stretch flex inset-[63.82%_5.1%_21.08%_81.93%] items-center justify-center overflow-clip px-[53px] py-[7px]" texto="Comentarios" />
    </div>
  );
}