import imgImage8 from "../Footer/4e911018752c850edcc1b9e83c48b1ec496024e2.png";

export default function LogoFooter() {
  return (
    <div className="h-full w-full relative" data-name="LogoFooter">
      <div className="absolute inset-0 pointer-events-none rounded-[4px]">
        <div aria-hidden className="absolute inset-0 rounded-[4px]">
          <div className="absolute bg-white inset-0 rounded-[4px]" />
          <div className="absolute inset-0 overflow-hidden rounded-[4px]">
            <img
              alt="Logo Cyber-Gourmet"
              className="absolute h-[145.9%] left-[-23.03%] max-w-none top-[-19.76%] w-[266.45%]"
              src={imgImage8}
            />
          </div>
        </div>
        <div aria-hidden className="absolute border-8 border-[rgba(255,255,255,0)] border-solid inset-[-8px] rounded-[12px] shadow-[0px_0px_0px_1px_rgba(0,0,0,0.2),0px_0px_2px_0px_rgba(0,0,0,0.08),0px_2px_6px_0px_rgba(0,0,0,0.1)]" />
      </div>
    </div>
  );
}
