import { useState } from "react";
import svgPaths from "./svg-nl57zv0way";
import img1 from "figma:asset/4e911018752c850edcc1b9e83c48b1ec496024e2.png";
import img2 from "figma:asset/a989c9088a9b92c5e224205202d8c79f33d34c47.png";
import img3 from "figma:asset/e1f2b024065461d3b9556f2184da512a79c1b0d8.png";

function NavLink({ children }: { children: React.ReactNode }) {
  return (
    <a
      href="#"
      className="text-[#00ff99] hover:text-white transition-colors duration-200 tracking-widest text-xs uppercase font-mono border-b border-transparent hover:border-[#00ff99] pb-0.5"
    >
      {children}
    </a>
  );
}

function CyberCorner({ position }: { position: "tl" | "tr" | "bl" | "br" }) {
  const paths: Record<string, string> = {
    tl: svgPaths.cornerTL,
    tr: svgPaths.cornerTR,
    bl: svgPaths.cornerBL,
    br: svgPaths.cornerBR,
  };
  const transforms: Record<string, string> = {
    tl: "",
    tr: "",
    bl: "",
    br: "",
  };
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 20 20"
      fill="none"
      className="absolute"
      style={{
        top: position.startsWith("t") ? 0 : "auto",
        bottom: position.startsWith("b") ? 0 : "auto",
        left: position.endsWith("l") ? 0 : "auto",
        right: position.endsWith("r") ? 0 : "auto",
      }}
    >
      <path d={paths[position]} stroke="#00ff99" strokeWidth="2" />
    </svg>
  );
}

function InputField({
  label,
  type = "text",
  placeholder,
}: {
  label: string;
  type?: string;
  placeholder?: string;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-[#00ff99] text-xs font-mono tracking-widest uppercase">
        {label}
      </label>
      <div className="relative">
        <input
          type={type}
          placeholder={placeholder}
          className="w-full bg-black/60 border border-[#00ff99]/40 text-white font-mono text-sm px-4 py-3 focus:outline-none focus:border-[#00ff99] focus:shadow-[0_0_8px_rgba(0,255,153,0.3)] transition-all duration-200 placeholder:text-[#00ff99]/30"
          style={{ clipPath: "polygon(0 0, calc(100% - 8px) 0, 100% 8px, 100% 100%, 0 100%)" }}
        />
      </div>
    </div>
  );
}

function SelectField({ label, options }: { label: string; options: string[] }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-[#00ff99] text-xs font-mono tracking-widest uppercase">
        {label}
      </label>
      <div className="relative">
        <select
          className="w-full bg-black/60 border border-[#00ff99]/40 text-white font-mono text-sm px-4 py-3 focus:outline-none focus:border-[#00ff99] focus:shadow-[0_0_8px_rgba(0,255,153,0.3)] transition-all duration-200 appearance-none cursor-pointer"
          style={{ clipPath: "polygon(0 0, calc(100% - 8px) 0, 100% 8px, 100% 100%, 0 100%)" }}
        >
          {options.map((opt) => (
            <option key={opt} value={opt} className="bg-black">
              {opt}
            </option>
          ))}
        </select>
        <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-[#00ff99]">▼</div>
      </div>
    </div>
  );
}

export default function Reservar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden" style={{ fontFamily: "monospace" }}>
      {/* Scanline overlay */}
      <div
        className="fixed inset-0 pointer-events-none z-50 opacity-[0.03]"
        style={{
          backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,255,153,0.3) 2px, rgba(0,255,153,0.3) 4px)",
        }}
      />

      {/* Header / Nav */}
      <header className="relative z-40 border-b border-[#00ff99]/20">
        <div className="max-w-7xl mx-auto px-6 py-5 flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div
              className="relative w-10 h-10 border border-[#00ff99] flex items-center justify-center"
              style={{ clipPath: "polygon(0 0, calc(100% - 6px) 0, 100% 6px, 100% 100%, 6px 100%, 0 calc(100% - 6px))" }}
            >
              <span className="text-[#00ff99] text-lg font-bold">N</span>
            </div>
            <div>
              <div className="text-white tracking-[0.3em] text-sm uppercase">NEON</div>
              <div className="text-[#00ff99] tracking-[0.5em] text-[10px] uppercase">KITCHEN</div>
            </div>
          </div>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-8">
            <NavLink>Inicio</NavLink>
            <NavLink>Menú</NavLink>
            <NavLink>Nosotros</NavLink>
            <NavLink>Reservar</NavLink>
            <NavLink>Contacto</NavLink>
          </nav>

          {/* Mobile menu button */}
          <button
            className="md:hidden text-[#00ff99] p-2"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d={menuOpen ? svgPaths.closeIcon : svgPaths.menuIcon} />
            </svg>
          </button>
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <div className="md:hidden border-t border-[#00ff99]/20 bg-black/95 px-6 py-4 flex flex-col gap-4">
            {["Inicio", "Menú", "Nosotros", "Reservar", "Contacto"].map((item) => (
              <NavLink key={item}>{item}</NavLink>
            ))}
          </div>
        )}
      </header>

      {/* Hero section */}
      <section className="relative overflow-hidden">
        <div
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: `url(${img1})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            filter: "brightness(0.25) hue-rotate(120deg)",
          }}
        />
        <div
          className="absolute inset-0 z-0"
          style={{
            background: "linear-gradient(180deg, rgba(0,0,0,0.6) 0%, rgba(0,255,153,0.05) 50%, rgba(0,0,0,0.9) 100%)",
          }}
        />
        {/* Grid overlay */}
        <div
          className="absolute inset-0 z-0 opacity-10"
          style={{
            backgroundImage: "linear-gradient(rgba(0,255,153,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,153,0.5) 1px, transparent 1px)",
            backgroundSize: "40px 40px",
          }}
        />

        <div className="relative z-10 max-w-7xl mx-auto px-6 py-24 md:py-36 text-center">
          <div className="inline-block mb-4">
            <span className="text-[#00ff99] text-xs tracking-[0.5em] uppercase font-mono border border-[#00ff99]/40 px-4 py-1">
              // SISTEMA DE RESERVAS //
            </span>
          </div>
          <h1 className="text-4xl md:text-7xl tracking-[0.15em] uppercase mb-4" style={{ textShadow: "0 0 30px rgba(0,255,153,0.5), 0 0 60px rgba(0,255,153,0.2)" }}>
            RESERVA TU
          </h1>
          <h1 className="text-4xl md:text-7xl tracking-[0.15em] uppercase text-[#00ff99] mb-6" style={{ textShadow: "0 0 30px rgba(0,255,153,0.8)" }}>
            EXPERIENCIA
          </h1>
          <p className="text-[#00ff99]/60 font-mono text-sm tracking-widest max-w-md mx-auto">
            Gastronomía de vanguardia en el corazón de la ciudad. Mesa para momentos que trascienden el tiempo.
          </p>
        </div>
      </section>

      {/* Divider */}
      <div className="border-t border-[#00ff99]/20 relative">
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#00ff99] to-transparent opacity-40" />
      </div>

      {/* Image customization section */}
      <section className="py-16 px-6 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { img: img1, label: "SALON PRINCIPAL", seats: "2–8 personas" },
            { img: img2, label: "TERRAZA NEON", seats: "2–12 personas" },
            { img: img3, label: "SALA PRIVADA", seats: "8–20 personas" },
          ].map(({ img, label, seats }) => (
            <div
              key={label}
              className="relative group cursor-pointer overflow-hidden border border-[#00ff99]/20 hover:border-[#00ff99] transition-all duration-300"
              style={{ clipPath: "polygon(0 0, calc(100% - 12px) 0, 100% 12px, 100% 100%, 12px 100%, 0 calc(100% - 12px))" }}
            >
              <img
                src={img}
                alt={label}
                className="w-full h-48 object-cover filter brightness-50 group-hover:brightness-75 transition-all duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <div className="text-[#00ff99] text-xs tracking-widest uppercase font-mono mb-1">{label}</div>
                <div className="text-white/60 text-xs font-mono">{seats}</div>
              </div>
              <CyberCorner position="tl" />
              <CyberCorner position="br" />
            </div>
          ))}
        </div>
      </section>

      {/* Reservation form */}
      <section className="py-8 px-6 pb-24 max-w-3xl mx-auto">
        <div className="relative border border-[#00ff99]/30 p-8 md:p-12" style={{ clipPath: "polygon(0 0, calc(100% - 20px) 0, 100% 20px, 100% 100%, 20px 100%, 0 calc(100% - 20px))" }}>
          <CyberCorner position="tl" />
          <CyberCorner position="tr" />
          <CyberCorner position="bl" />
          <CyberCorner position="br" />

          <div className="mb-8 text-center">
            <span className="text-[#00ff99] text-xs tracking-[0.4em] uppercase font-mono">
              ── FORMULARIO DE RESERVA ──
            </span>
          </div>

          {submitted ? (
            <div className="text-center py-12">
              <div
                className="inline-flex items-center justify-center w-16 h-16 border-2 border-[#00ff99] mb-6"
                style={{ clipPath: "polygon(0 0, calc(100% - 8px) 0, 100% 8px, 100% 100%, 8px 100%, 0 calc(100% - 8px))" }}
              >
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#00ff99" strokeWidth="2.5">
                  <polyline points="20 6 9 17 4 12" />
                </svg>
              </div>
              <div className="text-[#00ff99] tracking-widest text-lg uppercase mb-2">Reserva Confirmada</div>
              <div className="text-white/50 font-mono text-sm">Recibirás una confirmación en tu correo electrónico.</div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <InputField label="Nombre" placeholder="Tu nombre completo" />
              <InputField label="Apellido" placeholder="Tu apellido" />
              <InputField label="Email" type="email" placeholder="correo@ejemplo.com" />
              <InputField label="Teléfono" type="tel" placeholder="+34 000 000 000" />
              <InputField label="Fecha" type="date" />
              <InputField label="Hora" type="time" />
              <SelectField
                label="Número de personas"
                options={["1 persona", "2 personas", "3 personas", "4 personas", "5 personas", "6 personas", "7-10 personas", "11+ personas"]}
              />
              <SelectField
                label="Área preferida"
                options={["Sin preferencia", "Salón principal", "Terraza neon", "Sala privada"]}
              />
              <div className="md:col-span-2">
                <label className="text-[#00ff99] text-xs font-mono tracking-widest uppercase block mb-1.5">
                  Peticiones especiales
                </label>
                <textarea
                  rows={3}
                  placeholder="Alergias, ocasiones especiales, preferencias de mesa..."
                  className="w-full bg-black/60 border border-[#00ff99]/40 text-white font-mono text-sm px-4 py-3 focus:outline-none focus:border-[#00ff99] focus:shadow-[0_0_8px_rgba(0,255,153,0.3)] transition-all duration-200 resize-none placeholder:text-[#00ff99]/30"
                  style={{ clipPath: "polygon(0 0, calc(100% - 8px) 0, 100% 8px, 100% 100%, 0 100%)" }}
                />
              </div>
              <div className="md:col-span-2 pt-2">
                <button
                  type="submit"
                  className="w-full bg-[#00ff99] text-black font-mono text-sm tracking-widest uppercase py-4 hover:bg-white transition-colors duration-200 relative overflow-hidden group"
                  style={{ clipPath: "polygon(0 0, calc(100% - 12px) 0, 100% 12px, 100% 100%, 12px 100%, 0 calc(100% - 12px))" }}
                >
                  <span className="relative z-10">Confirmar Reserva</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#00ff99]/20 bg-black/80">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-10">
            {/* Brand */}
            <div className="md:col-span-1">
              <div className="flex items-center gap-3 mb-4">
                <div
                  className="w-8 h-8 border border-[#00ff99] flex items-center justify-center"
                  style={{ clipPath: "polygon(0 0, calc(100% - 5px) 0, 100% 5px, 100% 100%, 5px 100%, 0 calc(100% - 5px))" }}
                >
                  <span className="text-[#00ff99] text-sm font-bold">N</span>
                </div>
                <div>
                  <div className="text-white tracking-[0.3em] text-xs uppercase">NEON</div>
                  <div className="text-[#00ff99] tracking-[0.4em] text-[9px] uppercase">KITCHEN</div>
                </div>
              </div>
              <p className="text-white/40 text-xs font-mono leading-relaxed">
                Gastronomía de vanguardia. Experiencias que fusionan tradición y tecnología.
              </p>
            </div>

            {/* Links */}
            <div>
              <div className="text-[#00ff99] text-xs tracking-widest uppercase font-mono mb-4">Navegación</div>
              <ul className="space-y-2">
                {["Inicio", "Menú", "Nosotros", "Reservar", "Eventos"].map((item) => (
                  <li key={item}>
                    <a href="#" className="text-white/50 hover:text-[#00ff99] text-xs font-mono tracking-wider transition-colors duration-200">
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact */}
            <div>
              <div className="text-[#00ff99] text-xs tracking-widest uppercase font-mono mb-4">Contacto</div>
              <ul className="space-y-3">
                <li className="flex items-start gap-2">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#00ff99" strokeWidth="2" className="mt-0.5 shrink-0">
                    <path d={svgPaths.phone} />
                  </svg>
                  <span className="text-white/50 text-xs font-mono">+34 91 000 0000</span>
                </li>
                <li className="flex items-start gap-2">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#00ff99" strokeWidth="2" className="mt-0.5 shrink-0">
                    <path d={svgPaths.mail} />
                  </svg>
                  <span className="text-white/50 text-xs font-mono">hola@neonkitchen.es</span>
                </li>
                <li className="flex items-start gap-2">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#00ff99" strokeWidth="2" className="mt-0.5 shrink-0">
                    <path d={svgPaths.location} />
                  </svg>
                  <span className="text-white/50 text-xs font-mono">Calle Futura 42,<br />28001 Madrid</span>
                </li>
              </ul>
            </div>

            {/* Hours */}
            <div>
              <div className="text-[#00ff99] text-xs tracking-widest uppercase font-mono mb-4">Horario</div>
              <ul className="space-y-2">
                {[
                  { day: "Lun – Jue", hours: "13:00 – 23:00" },
                  { day: "Vie – Sáb", hours: "13:00 – 01:00" },
                  { day: "Domingo", hours: "13:00 – 22:00" },
                ].map(({ day, hours }) => (
                  <li key={day} className="flex justify-between gap-4">
                    <span className="text-white/40 text-xs font-mono">{day}</span>
                    <span className="text-[#00ff99]/70 text-xs font-mono">{hours}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Bottom bar */}
          <div className="border-t border-[#00ff99]/10 pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
            <span className="text-white/20 text-xs font-mono tracking-wider">
              © 2026 NEON KITCHEN — Todos los derechos reservados
            </span>
            <div className="flex items-center gap-5">
              {[
                { path: svgPaths.instagram, label: "Instagram" },
                { path: svgPaths.facebook, label: "Facebook" },
                { path: svgPaths.twitter, label: "Twitter" },
              ].map(({ path, label }) => (
                <a
                  key={label}
                  href="#"
                  aria-label={label}
                  className="text-white/30 hover:text-[#00ff99] transition-colors duration-200"
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                    <path d={path} />
                  </svg>
                </a>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
