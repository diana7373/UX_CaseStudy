import { useMemo, useState } from "react";
import { Menu, Search, UserRound } from "lucide-react";
import Logo from "../imports/Logo/Logo";
import LogoFooter from "../imports/LogoFooter/LogoFooter";
import ExternalLink from "../imports/ExternalLink/ExternalLink";
import Link from "../imports/Link/Link";
import LocationMarker from "../imports/LocationMarker/LocationMarker";
import Phone from "../imports/Phone/Phone";
import Mail from "../imports/Mail/Mail";
import Annotation from "../imports/Annotation/Annotation";

const navItems = ["CARTA", "PEDIDO", "PERSONALIZACION", "CONTACTO", "SOBRE NOSOTROS", "RESERVAR"];

const buildGroups = [
  { key: "pan", title: "[PAN]", color: "violet", options: ["Clásico", "Neón Púrpura", "Carbón Negro", "Sésamo Dorado"] },
  { key: "proteina", title: "[PROTEÍNA]", color: "green", options: ["Res Premium", "Doble Res", "Pollo Crispy", "Vegetal X"] },
  { key: "queso", title: "[QUESO]", color: "red", options: ["Cheddar", "Azul Intenso", "Suizo", "Sin Queso"] },
  { key: "toppings", title: "[TOPPINGS]", color: "violet", options: ["🥬 Lechuga", "🍅 Tomate", "🧅 Cebolla", "🌶 Pepinillo", "🥓 Bacon", "🥑 Aguacate"] },
  { key: "salsas", title: "[SALSAS]", color: "green", options: ["Mayonesa", "Ketchup", "Mostaza", "BBQ Ahumada", "Picante 🔥", "Especial Casa"] },
] as const;

type SelectionKey = typeof buildGroups[number]["key"];
type Selections = Record<SelectionKey, string>;

const colorStyles = {
  violet: {
    border: "border-[#e047ff]",
    text: "text-[#e047ff]",
    glow: "shadow-[0_0_28px_rgba(224,71,255,.25)]",
    bg: "bg-[#32163f]",
  },
  green: {
    border: "border-[#00c791]",
    text: "text-[#00d99e]",
    glow: "shadow-[0_0_28px_rgba(0,199,145,.22)]",
    bg: "bg-[#0f473b]",
  },
  red: {
    border: "border-[#ff3d3d]",
    text: "text-[#ff4747]",
    glow: "shadow-[0_0_28px_rgba(255,61,61,.22)]",
    bg: "bg-[#49211e]",
  },
};

function Header() {
  return (
    <header className="border-b border-black bg-[#572364] text-white">
      <div className="mx-auto grid max-w-[1947px] grid-cols-[1fr_auto_1fr] items-center gap-4 px-6 py-3 md:px-10 md:py-5">
        <button className="justify-self-start p-2 text-white transition hover:text-[#d94cff]" aria-label="Abrir menú">
          <Menu className="h-8 w-8" strokeWidth={2.4} />
        </button>
        <Logo className="relative h-[74px] w-[75px] shrink-0 md:h-[92px] md:w-[93px]" />
        <div className="flex items-center justify-end gap-4">
          <div className="hidden h-7 w-[32vw] max-w-[300px] border border-black bg-black md:block" />
          <button className="grid h-8 w-8 place-items-center bg-[#d1a0de] text-black transition hover:bg-[#c48ed1]"><Search className="h-5 w-5" /></button>
          <button className="grid h-8 w-8 place-items-center bg-white text-black transition hover:bg-gray-200"><UserRound className="h-5 w-5" /></button>
        </div>
      </div>
      <nav className="grid grid-cols-2 border-t border-black md:grid-cols-6">
        {navItems.map((item) => (
          <a
            key={item}
            href="#reservar"
            className={`flex min-h-[46px] items-center justify-center border-b border-r border-black px-1.5 text-center font-['Press_Start_2P'] text-[9px] leading-none transition hover:bg-[#6f2b80] hover:text-[#16c59a] sm:text-[10px] lg:text-[11px] xl:text-xs ${item === "PERSONALIZACION" ? "tracking-[-0.08em]" : "tracking-[-0.03em]"}`}
          >
            <span className="whitespace-nowrap">{item}</span>
          </a>
        ))}
      </nav>
    </header>
  );
}

function CornerPixels({ color }: { color: string }) {
  return (
    <>
      <span className={`absolute -left-1 -top-1 h-3 w-3 ${color}`} />
      <span className={`absolute -right-1 -top-1 h-3 w-3 ${color}`} />
      <span className={`absolute -bottom-1 -left-1 h-3 w-3 ${color}`} />
      <span className={`absolute -bottom-1 -right-1 h-3 w-3 ${color}`} />
    </>
  );
}

function OptionGroup({ group, selected, onPick }: { group: typeof buildGroups[number]; selected: string; onPick: (key: SelectionKey, value: string) => void }) {
  const tone = colorStyles[group.color];
  const pixel = group.color === "violet" ? "bg-[#e047ff]" : group.color === "green" ? "bg-[#00c791]" : "bg-[#ff3d3d]";

  return (
    <fieldset className={`relative border-2 ${tone.border} bg-[#111318]/95 p-4 ${tone.glow}`}>
      <CornerPixels color={pixel} />
      <legend className={`px-2 font-['Press_Start_2P'] text-sm ${tone.text}`}>{group.title}</legend>
      <div className="grid grid-cols-2 gap-3 pt-2">
        {group.options.map((option) => {
          const isActive = option === selected;
          return (
            <button
              key={option}
              type="button"
              onClick={() => onPick(group.key, option)}
              className={`border-2 px-3 py-3 font-['Press_Start_2P'] text-[9px] leading-tight transition duration-150 hover:-translate-y-0.5 hover:shadow-[0_0_18px_rgba(224,71,255,.35)] ${isActive ? `${tone.border} ${tone.bg} text-white` : "border-[#314155] bg-[#07090d] text-white/90 hover:border-white/70"}`}
            >
              {option}
            </button>
          );
        })}
      </div>
    </fieldset>
  );
}

function ArsenalBuilder() {
  const initialSelections = useMemo(() => Object.fromEntries(buildGroups.map((group) => [group.key, group.options[0]])) as Selections, []);
  const [selections, setSelections] = useState<Selections>(initialSelections);
  const [spice, setSpice] = useState(50);

  const handlePick = (key: SelectionKey, value: string) => {
    setSelections((current) => ({ ...current, [key]: value }));
  };

  return (
    <section id="reservar" className="relative mx-auto w-full max-w-[1180px] px-7 pb-14 sm:px-9 md:px-12 md:pb-20">
      <div className="mb-7 text-center">
        <h2 className="font-['Press_Start_2P'] text-3xl leading-tight text-[#e047ff] drop-shadow-[0_0_14px_rgba(224,71,255,.95)] md:text-5xl">Construye tu Arsenal</h2>
        <p className="mt-3 font-['Average_Sans'] text-sm font-bold text-[#6da1ad] md:text-base">Hackea cada capa. Personaliza cada ingrediente. Domina tu creación.</p>
      </div>

      <div className="grid gap-7 lg:grid-cols-[1fr_.96fr]">
        <div className="space-y-5">
          {buildGroups.map((group) => (
            <OptionGroup key={group.key} group={group} selected={selections[group.key]} onPick={handlePick} />
          ))}

          <fieldset className="relative border-2 border-[#ff3d3d] bg-[#111318]/95 p-4 shadow-[0_0_28px_rgba(255,61,61,.22)]">
            <CornerPixels color="bg-[#ff3d3d]" />
            <legend className="px-2 font-['Press_Start_2P'] text-sm text-[#ff4747]">[NIVEL PICANTE]</legend>
            <input
              aria-label="Nivel picante"
              type="range"
              min="0"
              max="100"
              value={spice}
              onChange={(event) => setSpice(Number(event.target.value))}
              className="mt-4 h-2 w-full accent-[#ff3d3d]"
            />
            <div className="mt-3 flex justify-between font-['Press_Start_2P'] text-[9px] text-[#7e8a97]">
              <span>Suave</span>
              <span className="text-[#ff4747]">{spice}%</span>
              <span>Extremo 🔥</span>
            </div>
          </fieldset>
        </div>

        <aside className="relative self-start border-2 border-[#00c791] bg-[#15191b]/95 p-6 shadow-[0_0_38px_rgba(0,199,145,.28)] lg:sticky lg:top-6">
          <CornerPixels color="bg-[#00c791]" />
          <h3 className="mb-5 text-center font-['Press_Start_2P'] text-2xl text-[#00d99e]">Tu Creación</h3>
          <div className="space-y-3">
            {buildGroups.map((group) => {
              const tone = colorStyles[group.color];
              return (
                <div key={group.key} className={`border-2 ${tone.border} ${tone.bg} px-4 py-3 text-center font-['Press_Start_2P'] text-[10px] uppercase ${tone.text}`}>
                  {selections[group.key]}
                </div>
              );
            })}
          </div>

          <div className="my-7 space-y-3 font-['Average_Sans'] text-sm font-bold text-[#60707d]">
            <p className="flex justify-between"><span>Ingredientes:</span><span className="text-[#00d99e]">5</span></p>
            <p className="flex justify-between"><span>Nivel Picante:</span><span className="text-[#ff4747]">{spice}%</span></p>
            <p className="flex justify-between"><span>Estado:</span><span className="text-[#e047ff]">ACTIVO</span></p>
          </div>

          <button className="w-full bg-[#16c59a] px-6 py-5 font-['Press_Start_2P'] text-sm text-black shadow-[0_0_20px_rgba(22,197,154,.55)] transition hover:-translate-y-0.5 hover:bg-[#e047ff] hover:text-white hover:shadow-[0_0_24px_rgba(224,71,255,.55)]">
            HACKEAR PEDIDO
          </button>
        </aside>
      </div>
    </section>
  );
}


export default function App() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Header />
      <main className="relative overflow-hidden bg-black">
        <div className="pointer-events-none absolute inset-0 opacity-30 [background-image:linear-gradient(rgba(255,255,255,.05)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.04)_1px,transparent_1px)] [background-size:26px_26px]" />
        <section className="relative mx-auto flex min-h-[160px] max-w-[1180px] items-center justify-center px-7 py-10 text-center sm:px-9 md:px-12 md:py-14">
          <h1 className="max-w-5xl font-['Press_Start_2P'] text-2xl leading-[1.55] tracking-tight text-white md:text-4xl lg:text-5xl">Diseñada por ti,<br />perfeccionada por el fuego.</h1>
        </section>
        <ArsenalBuilder />
      </main>
      <footer className="bg-[#572364] py-12 mt-20">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-start">
            {/* Columna Izquierda */}
            <div className="flex flex-col gap-4 w-1/3">
              <button className="bg-[#572364] px-6 py-3 font-['Average_Sans'] text-[20px] border border-white hover:bg-[#6b2d7a] transition-colors flex items-center gap-3 w-fit">
                <div className="w-6 h-6">
                  <ExternalLink />
                </div>
                Compartir
              </button>
              <button className="bg-[#572364] px-6 py-3 font-['Average_Sans'] text-[20px] border border-white hover:bg-[#6b2d7a] transition-colors flex items-center gap-3 w-fit">
                <div className="w-6 h-6">
                  <Link />
                </div>
                Enlace
              </button>
              <button className="bg-[#572364] px-6 py-3 font-['Average_Sans'] text-[20px] border border-white hover:bg-[#6b2d7a] transition-colors flex items-center gap-3 w-fit">
                <div className="w-6 h-6">
                  <LocationMarker />
                </div>
                Ubicación
              </button>
            </div>

            {/* Logo Central */}
            <div className="flex items-center justify-center w-1/3">
              <div className="h-[120px] w-[120px]">
                <LogoFooter />
              </div>
            </div>

            {/* Columna Derecha */}
            <div className="flex flex-col gap-4 w-1/3 items-end">
              <button className="bg-[#572364] px-6 py-3 font-['Average_Sans'] text-[20px] border border-white hover:bg-[#6b2d7a] transition-colors flex items-center gap-3 w-fit">
                <div className="w-6 h-6">
                  <Phone />
                </div>
                Teléfono
              </button>
              <button className="bg-[#572364] px-6 py-3 font-['Average_Sans'] text-[20px] border border-white hover:bg-[#6b2d7a] transition-colors flex items-center gap-3 w-fit">
                <div className="w-6 h-6">
                  <Mail />
                </div>
                Email
              </button>
              <button className="bg-[#572364] px-6 py-3 font-['Average_Sans'] text-[20px] border border-white hover:bg-[#6b2d7a] transition-colors flex items-center gap-3 w-fit">
                <div className="w-6 h-6">
                  <Annotation />
                </div>
                Comentarios
              </button>
            </div>
          </div>

          <div className="text-center mt-8">
            <p className="font-['Average_Sans'] text-[18px]">
              © 2026 Cyber-Gourmet S.L. Todos los derechos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
