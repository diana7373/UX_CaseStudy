import svgPaths from "./svg-8qpsx9zz9r";

export default function ExternalLink() {
  return (
    <div className="relative size-full" data-name="external-link">
      <div className="absolute inset-[16.67%]" data-name="Vector">
        <div className="absolute inset-[-2.78%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 38 38">
            <path d={svgPaths.p36cddc80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}