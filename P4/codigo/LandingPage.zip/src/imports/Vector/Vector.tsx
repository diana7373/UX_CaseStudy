import svgPaths from "./svg-tnai7so0nb";

export default function Vector() {
  return (
    <div className="relative size-full" data-name="Vector">
      <div className="absolute inset-[-2.86%_-2.63%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 37">
          <path d={svgPaths.p4188600} id="Vector" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </svg>
      </div>
    </div>
  );
}