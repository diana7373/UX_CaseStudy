import svgPaths from "./svg-chovo86l7j";

export default function Phone() {
  return (
    <div className="relative size-full" data-name="phone">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-2.15%_-2.12%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 49.25 48.5">
            <path d={svgPaths.pc447980} id="Vector" stroke="var(--stroke-0, #F7EEEF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}