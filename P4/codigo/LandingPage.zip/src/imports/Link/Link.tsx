import svgPaths from "./svg-ryjw0iydog";

export default function Link() {
  return (
    <div className="relative size-full" data-name="link">
      <div className="absolute inset-[12.7%_12.7%_12.3%_12.3%]" data-name="Vector">
        <div className="absolute inset-[-2.34%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 44.75 44.75">
            <path d={svgPaths.p26bfb720} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}