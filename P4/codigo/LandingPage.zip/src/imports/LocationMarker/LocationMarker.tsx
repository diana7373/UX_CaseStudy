import svgPaths from "./svg-zgkzn7vedj";

export default function LocationMarker() {
  return (
    <div className="relative size-full" data-name="location-marker">
      <div className="absolute inset-[12.5%_16.67%_10.48%_16.67%]" data-name="Vector">
        <div className="absolute inset-[-1.94%_-2.24%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 46.6667 53.6057">
            <path d={svgPaths.p1b472300} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[33.33%_37.5%_41.67%_37.5%]" data-name="Vector">
        <div className="absolute inset-[-5.97%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.75 18.75">
            <path d={svgPaths.p3081f780} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}