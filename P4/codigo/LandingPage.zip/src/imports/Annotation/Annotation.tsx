import svgPaths from "./svg-ljnptovhls";

export default function Annotation() {
  return (
    <div className="relative size-full" data-name="annotation">
      <div className="absolute inset-[16.67%_12.5%]" data-name="Vector">
        <div className="absolute inset-[-1.76%_-1.55%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 66.5 58.6667">
            <path d={svgPaths.p1f00ba00} id="Vector" stroke="var(--stroke-0, #F7EEEF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}