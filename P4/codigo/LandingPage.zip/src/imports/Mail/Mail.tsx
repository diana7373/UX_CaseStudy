import svgPaths from "./svg-86sxcblids";

export default function Mail() {
  return (
    <div className="relative size-full" data-name="mail">
      <div className="absolute inset-[20.83%_12.5%]" data-name="Vector">
        <div className="absolute inset-[-2.41%_-1.59%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 65.0004 43.4167">
            <path d={svgPaths.p2524700} id="Vector" stroke="var(--stroke-0, #F7EEEF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}