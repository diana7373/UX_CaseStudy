import imgImage8 from "./d968a1a3da3d64fdfe37c237be6b8787d19d829b.png";
type ButtonProps = {
  className?: string;
  propiedad1?: "boton" | "hover" | "pressed";
};

function Button({ className, propiedad1 = "boton" }: ButtonProps) {
  const isPressed = propiedad1 === "pressed";
  return (
    <div className={className || `relative rounded-[8px] ${isPressed ? "bg-[#b040cc] cursor-pointer" : propiedad1 === "hover" ? "bg-[#823795] cursor-pointer" : "bg-[#572364]"}`}>
      <div className="content-stretch flex items-center overflow-clip px-[16px] py-[8px] relative rounded-[inherit] size-full">
        <div className={`[word-break:break-word] flex flex-col font-["Press_Start_2P:Regular",sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-center whitespace-nowrap ${isPressed ? "text-black" : "text-white"}`}>
          <p className="leading-[1.5]">Button</p>
        </div>
      </div>
      <div aria-hidden className="absolute border border-[#a1a1aa] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(18,18,23,0.05)]" />
    </div>
  );
}

export default function Component({ className }: { className?: string }) {
  return (
    <div className={className || "h-[337px] relative w-[223.409px]"} data-name="Component 3">
      <div className="absolute bg-[#cd2e2e] inset-[63.8%_14.51%_24.33%_28.2%] rounded-[8px]" data-name="Button">
        <div className="content-stretch flex items-center overflow-clip px-[16px] py-[8px] relative rounded-[inherit] size-full">
          <div className="[word-break:break-word] flex flex-col font-['Press_Start_2P:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#27272a] text-[16px] text-center whitespace-nowrap">
            <p className="leading-[1.5]">Button</p>
          </div>
        </div>
        <div aria-hidden className="absolute border border-[#a1a1aa] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(18,18,23,0.05)]" />
      </div>
      <Button className="absolute bg-[#572364] inset-[88.13%_14.51%_0_28.2%] rounded-[8px]" />
      <div className="absolute contents left-0 right-0 top-0" data-name="Image box">
        <div className="absolute aspect-[226/175] left-0 pointer-events-none right-0 rounded-[4px] top-0" data-name="image 8">
          <div aria-hidden className="absolute inset-0 rounded-[4px]">
            <div className="absolute bg-white inset-0 rounded-[4px]" />
            <div className="absolute inset-0 overflow-hidden rounded-[4px]">
              <img alt="" className="absolute h-[118.44%] left-[-8.77%] max-w-none top-[-7.89%] w-[117.7%]" src={imgImage8} />
            </div>
          </div>
          <div aria-hidden className="absolute border-8 border-[rgba(255,255,255,0)] border-solid inset-[-8px] rounded-[12px] shadow-[0px_0px_0px_1px_rgba(0,0,0,0.2),0px_0px_2px_0px_rgba(0,0,0,0.08),0px_2px_6px_0px_rgba(0,0,0,0.1)]" />
        </div>
      </div>
    </div>
  );
}